const String MAINAPI = "https://lunarsenterprises.com:6032/getbike/";


const String registerAPI = "${MAINAPI}register";

const String loginAPI = "${MAINAPI}login";

const String forgotPasswordAPI = "${MAINAPI}forgotpassword";

const String verifyOtpAPI = "${MAINAPI}verifyOtp";

const String changePasswordAPI = "${MAINAPI}changepassword";

// admin

const String AddBikeAPI = "${MAINAPI}add/bike";

const String deleteBikeAPI = "${MAINAPI}delete/bike";

const String AllBikesAPI = "${MAINAPI}list/bike";

const String EditBikesAPI = "${MAINAPI}edit/bike";

const String BikeCentersAPI = "${MAINAPI}list/center";






/// not  added


const String BookingAPI = "${MAINAPI}add/booking";

const String MybookingAPI = "${MAINAPI}list/booking";

const String ProfileUpdateAPI = "${MAINAPI}edit/profile";

const String AddDocumentsAPI = "${MAINAPI}add/document";

const String supportReqAPI = "${MAINAPI}add/contact";

const String NotificationAPI = "${MAINAPI}list/notification";

const String GetUserAPI = "${MAINAPI}list/user";

const String GetSupportAPI = "${MAINAPI}list/contact";

const String BookingStatusAPI = "${MAINAPI}update/status";



