import 'dart:convert';
import 'package:getbike_admin/APIs/apis.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:http/http.dart' as http;


class BikeController {
  List<BikeModel> bikeList = [];
  List<BikeModel> topRatedBikes = [];
  List<BikeReviewModel> allReviews = []; 

  Future<void> fetchBikes() async {
    final url = Uri.parse(AllBikesAPI);

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
      );

      print("sts code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response : $response");
        print(decodedData);

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];

          bikeList = dataList.map((bike) => BikeModel.fromJson(bike)).toList();

          // ✅ Gather all reviews from all bikes
          allReviews = bikeList
              .expand((bike) => bike.bikereviews)
              .toList();

          // ✅ Sort bikeList by rating (descending) and take top 4
          bikeList.sort((a, b) {
            final bRating = b.bRatings ?? 0.0;
            final aRating = a.bRatings ?? 0.0;
            return bRating.compareTo(aRating);
          });
          topRatedBikes = bikeList.take(4).toList();

          print("Top Rated Bikes:");
          for (var bike in topRatedBikes) {
            print("${bike.bName} - Rating: ${bike.bRatings}");
          }

          print("Total Reviews: ${allReviews.length}");
        } else {
          bikeList = [];
          topRatedBikes = [];
          allReviews = [];
        }
      } else {
        print("Failed to load bikes: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching bikes: $e");
    }
  }
}



class MyBookingController {
  List<BookingModel> bookingReqList = [];
  List<BookingModel> onrideList = [];
  List<BookingModel> completedList = [];
  List<BookingModel> upcomingList = [];
  List<BookingModel> cancelledList = [];
  List<BookingModel> cancelreq = [];
  List<BookingModel> Extendbookingreq = [];


  Future<void> fetchBikes() async {
    final url = Uri.parse(MybookingAPI);

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        // body: jsonEncode({"user_id": user_id}),
      );

      print("sts code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response : ${response.body}");

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];
          List<BookingModel> mybookingList =
              dataList.map((bike) => BookingModel.fromJson(bike)).toList();

          // Separate lists based on status
          bookingReqList = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "pending")
              .toList();

          onrideList = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "onride")
              .toList();

          completedList = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "completed")
              .toList();

          upcomingList = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "approved")
              .toList();

          cancelledList = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "cancelled")
              .toList();

              cancelreq = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "cancelreq")
              .toList();
              
                Extendbookingreq = mybookingList
              .where((bike) => bike.bStatus?.toLowerCase() == "extendedreq")
              .toList();
        } else {
          bookingReqList = [];
          onrideList = [];
          completedList = [];
          upcomingList = [];
          cancelledList = [];
        }
      } else {
        print("Failed to load bikes: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching bikes: $e");
    }
  }
}






// class BikesearchhController {
//   List<BikeModel> searchlist = [];


//   Future<void> fetchBikes(String search) async {
//     final url = Uri.parse(AllBikesAPI);

//   var data = {
//       "search": search,
//     };

//     try {
//       print(url);
//       final response = await http.post(
//         url,
//         headers: {
//           'Content-Type': 'application/json',
//         },
//             body: jsonEncode(data),
//       );

//       print("sts code : ${response.statusCode}");

//       if (response.statusCode == 200) {
//         final decodedData = json.decode(response.body);
//         print("Response : $response");
//         print(decodedData);

//         if (decodedData['result'] == true && decodedData['list'] != null) {
//           final List<dynamic> dataList = decodedData['list'];
//           searchlist = dataList.map((bike) => BikeModel.fromJson(bike)).toList();

//         } else {
//           searchlist = [];
//         }
//       } else {
//         print("Failed to load bikes: ${response.statusCode}");
//       }
//     } catch (e) {
//       print("Error fetching bikes: $e");
//     }
//   }
// }







class NotificationController {
  List<NotificationModel> notificationList = [];

  Future<void> fetchNotifications() async {
    final url = Uri.parse(NotificationAPI); // Replace with your API variable

  // final SharedPreferences prefs = await SharedPreferences.getInstance();
  // String? user_id = prefs.getString("user_id");

    // var data = {
    //   "user_id": user_id,
    // };

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        // body: jsonEncode(data),
      );

      print("Status code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response body: ${response.body}");

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];
          notificationList = dataList
              .map((item) => NotificationModel.fromJson(item))
              .toList();
        } else {
          notificationList = [];
        }
      } else {
        print("Failed to load notifications: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching notifications: $e");
    }
  }
}







class UserController {
  List<UserModel> userList = [];

  Future<void> fetchuser() async {
    final url = Uri.parse(GetUserAPI); // Replace with your API variable

  // final SharedPreferences prefs = await SharedPreferences.getInstance();
  // String? user_id = prefs.getString("user_id");

    // var data = {
      // "user_id": user_id,
    // };

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        // body: jsonEncode(data),
      );

      print("Status code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response body: ${response.body}");

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];
          userList = dataList
              .map((item) => UserModel.fromJson(item))
              .toList();
        } else {
          userList = [];
        }
      } else {
        print("Failed to load notifications: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching notifications: $e");
    }
  }
}



class SupportController {
  List<SupportModel> supportList = [];

  Future<void> fetchdb() async {
    final url = Uri.parse(GetSupportAPI); 

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        // body: jsonEncode(data),
      );

      print("Status code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response body: ${response.body}");

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];
          supportList = dataList
              .map((item) => SupportModel.fromJson(item))
              .toList();
        } else {
          supportList = [];
        }
      } else {
        print("Failed to load notifications: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching notifications: $e");
    }
  }
}



class CentersController {
  List<BikeCenters> centersList = [];

  Future<void> fetchdb() async {
    final url = Uri.parse(BikeCentersAPI); 

    try {
      print(url);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        // body: jsonEncode(data),
      );

      print("Status code : ${response.statusCode}");

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("Response body: ${response.body}");

        if (decodedData['result'] == true && decodedData['list'] != null) {
          final List<dynamic> dataList = decodedData['list'];
          centersList = dataList
              .map((item) => BikeCenters.fromJson(item))
              .toList();
        } else {
          centersList = [];
        }
      } else {
        print("Failed to load notifications: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching notifications: $e");
    }
  }
}
