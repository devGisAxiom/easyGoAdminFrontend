class BikeModel {
  int bId;
  String bName;
  double bRatings;
  String bDescription;
  int bPrice;
  String bStatus;
  String bLocation;
  String bExtras;
  double bMilage;
  String bGeartype;
  String bFueltype;
  double bBhp;
  String? bImage;
  String bReviews;
  int distance;
  int maxSpeed;
  String maintainceStatus;
  String center;
  List<BikeReviewModel> bikereviews;
  List<BikeImageModel> bikeimages;

  BikeModel({
    required this.bId,
    required this.bName,
    required this.bRatings,
    required this.bDescription,
    required this.bPrice,
    required this.bStatus,
    required this.bLocation,
    required this.bExtras,
    required this.bMilage,
    required this.bGeartype,
    required this.bFueltype,
    required this.bBhp,
    required this.bImage,
    required this.bReviews,
    required this.distance,
    required this.maxSpeed,
    required this.maintainceStatus,
    required this.center,
    required this.bikereviews,
    required this.bikeimages,
  });

  factory BikeModel.fromJson(Map<String, dynamic> json) {
    return BikeModel(
      bId: json["b_id"] ?? 0,
      bName: json["b_name"] ?? "",
      bRatings: (json["b_ratings"] ?? 0).toDouble(),
      bDescription: json["b_description"] ?? "",
      bPrice: json["b_price"] ?? 0,
      bStatus: json["b_status"] ?? "",
      bLocation: json["b_location"] ?? "",
      bExtras: json["b_extras"] ?? "",
      bMilage: (json["b_milage"] ?? 0).toDouble(),
      bGeartype: json["b_geartype"] ?? "",
      bFueltype: json["b_fueltype"] ?? "",
      bBhp: (json["b_bhp"] ?? 0).toDouble(),
      bImage: json["b_image"],
      bReviews: json["b_reviews"] ?? "",
      distance: json["distance"] ?? 0,
      maxSpeed: json["max_speed"] ?? 0,
      maintainceStatus: json["maintaince_status"] ?? "",
      center: json["center"] ?? "",
      bikereviews: (json["bikereviews"] as List<dynamic>? ?? [])
          .map((x) => BikeReviewModel.fromJson(x))
          .toList(),
      bikeimages: (json["bikeimages"] as List<dynamic>? ?? [])
          .map((x) => BikeImageModel.fromJson(x))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'b_id': bId,
      'b_name': bName,
      'b_ratings': bRatings,
      'b_description': bDescription,
      'b_price': bPrice,
      'b_status': bStatus,
      'b_location': bLocation,
      'b_extras': bExtras,
      'b_milage': bMilage,
      'b_geartype': bGeartype,
      'b_fueltype': bFueltype,
      'b_bhp': bBhp,
      'b_image': bImage,
      'b_reviews': bReviews,
      'distance': distance,
      'max_speed': maxSpeed,
      'maintaince_status': maintainceStatus,
      'center': center,
      'bikereviews': bikereviews.map((e) => e.toJson()).toList(),
      'bikeimages': bikeimages.map((e) => e.toJson()).toList(),
    };
  }
}

class BikeReviewModel {
  int brId;
  int brUsedId;
  int brBikeId;
  String brReview;
  int brRating;
  String date;
  String? uName;
  String? uProfilePic;

  BikeReviewModel({
    required this.brId,
    required this.brUsedId,
    required this.brBikeId,
    required this.brReview,
    required this.brRating,
    required this.date,
    this.uName,
    this.uProfilePic,
  });

  factory BikeReviewModel.fromJson(Map<String, dynamic> json) {
    return BikeReviewModel(
      brId: json["br_id"] ?? 0,
      brUsedId: json["br_used_id"] ?? 0,
      brBikeId: json["br_bike_id"] ?? 0,
      brReview: json["br_review"] ?? "",
      brRating: (json["br_rating"] is int)
          ? json["br_rating"]
          : int.tryParse(json["br_rating"].toString()) ?? 0,
      date: json["date"] ?? "",
      uName: json["u_name"], // can be null
      uProfilePic: json["u_profile_pic"], // can be null
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'br_id': brId,
      'br_used_id': brUsedId,
      'br_bike_id': brBikeId,
      'br_review': brReview,
      'br_rating': brRating,
      'date': date,
      'u_name': uName,
      'u_profile_pic': uProfilePic,
    };
  }
}

class BikeImageModel {
  int imgId;
  int bikeId;
  String imagePath;

  BikeImageModel({
    required this.imgId,
    required this.bikeId,
    required this.imagePath,
  });

  factory BikeImageModel.fromJson(Map<String, dynamic> json) {
    return BikeImageModel(
      imgId: json[" img_id"] ?? 0, // Note: space in key
      bikeId: json["bike_id"] ?? 0,
      imagePath: json["image_path"] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'img_id': imgId,
      'bike_id': bikeId,
      'image_path': imagePath,
    };
  }
}







class BookingModel {
  int bId;
  int bUId;
  int bBkId;
  int bPrice;
  int bRentAmount;
  String bPickupLocation;
  String bPickupDate;
  String bPicupTime;
  String bDropLocation;
  String bDropDate;
  String bDropTime;
  String bRole;
  String bType;
  String bMessage;
  String bookingDate;
  String invoice;
  String bSelfie;
  String bAdharcard;
  String bLicense;
  String viewReason;
  String bBikeName;
  dynamic extendReason;
  String bPaymentStatus;
  String bStatus;
  int uId;
  String uName;
  String uEmail;
  int uMobile;
  String uRole;
  List bikeImagePath;

  BookingModel({
    required this.bId,
    required this.bUId,
    required this.bBkId,
    required this.bPrice,
    required this.bRentAmount,
    required this.bPickupLocation,
    required this.bPickupDate,
    required this.bPicupTime,
    required this.bDropLocation,
    required this.bDropDate,
    required this.bDropTime,
    required this.bRole,
    required this.bType,
    required this.bMessage,
    required this.bookingDate,
    required this.invoice,
    required this.bSelfie,
    required this.bAdharcard,
    required this.bLicense,
    required this.viewReason,
    required this.bBikeName,
    required this.extendReason,
    required this.bPaymentStatus,
    required this.bStatus,
    required this.uId,
    required this.uName,
    required this.uEmail,
    required this.uMobile,
    required this.uRole,
    required this.bikeImagePath,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json) {
    return BookingModel(
      bId: json["b_id"] ?? 0,
      bUId: json["b_u_id"] ?? 0,
      bBkId: json["b_bk_id"] ?? 0,
      bPrice: json["b_price"] ?? 0,
      bRentAmount: json["b_rent_amount"] ?? 0,
      bPickupLocation: json["b_pickup_location"] ?? "",
      bPickupDate: json["b_pickup_date"] ?? "",
      bPicupTime: json["b_picup_time"] ?? "",
      bDropLocation: json["b_drop_location"] ?? "",
      bDropDate: json["b_drop_date"] ?? "",
      bDropTime: json["b_drop_time"] ?? "",
      bRole: json["b_role"] ?? "",
      bType: json["b_type"] ?? "",
      bMessage: json["b_message"] ?? "",
      bookingDate: json["booking_date"] ?? "",
      invoice: json["invoice"] ?? "",
      bSelfie: json["b_selfie"] ?? "",
      bAdharcard: json["b_adharcard"] ?? "",
      bLicense: json["b_license"] ?? "",
      viewReason: json["view_reason"] ?? "",
      bBikeName: json["b_bike_name"] ?? "",
      extendReason: json["extend_reason"],
      bPaymentStatus: json["b_payment_status"] ?? "",
      bStatus: json["b_status"] ?? "",
      uId: json["u_id"] ?? 0,
      uName: json["u_name"] ?? "",
      uEmail: json["u_email"] ?? "",
      uMobile: json["u_mobile"] ?? 0,
      uRole: json["u_role"] ?? "",
      bikeImagePath: json["bikeImagePath"] ?? [],
    );
  }
}

// class BookingModel {
//    int bId;
//     int bUId;
//     int bBkId;
//     int bPrice;
//     String bPickupLocation;
//     dynamic bPickupDate;
//     String bPicupTime;
//     String bDropLocation;
//     dynamic bDropDate;
//     String bDropTime;
//     String bRole;
//     String bType;
//     String bMessage;
//     dynamic bookingDate;
//     String invoice;
//     String bStatus;
//     String bSelfie;
//     String bAdharcard;
//     String bLicense;
//     String bBikeName;

//   BookingModel({
//         required this.bId,
//         required this.bUId,
//         required this.bBkId,
//         required this.bPrice,
//         required this.bPickupLocation,
//         required this.bPickupDate,
//         required this.bPicupTime,
//         required this.bDropLocation,
//         required this.bDropDate,
//         required this.bDropTime,
//         required this.bRole,
//         required this.bType,
//         required this.bMessage,
//         required this.bookingDate,
//         required this.invoice,
//         required this.bStatus,
//         required this.bSelfie,
//         required this.bAdharcard,
//         required this.bLicense,
//         required this.bBikeName,
//   });

//   factory BookingModel.fromJson(Map<String, dynamic> json) {
//     return BookingModel(
//  bId: json["b_id"] ?? "",
//     bUId: json["b_u_id"] ?? "" ,
//     bBkId: json["b_bk_id"] ?? "",
//     bPrice: json["b_price"] ?? "",
//     bPickupLocation: json["b_pickup_location"] ?? "",
//     bPickupDate: json["b_pickup_date"] ?? "",
//     bPicupTime: json["b_picup_time"] ?? "",
//     bDropLocation: json["b_drop_location"] ?? "",
//     bDropDate: json["b_drop_date"] ?? "",
//     bDropTime: json["b_drop_time"] ?? "",
//     bRole: json["b_role"] ?? "",
//     bType: json["b_type"] ?? "",
//     bMessage: json["b_message"] ?? "",
//     bookingDate: json["booking_date"] ?? "",
//     invoice: json["invoice"] ?? "",
//     bStatus: json["b_status"] ?? "",
//     bSelfie: json["b_selfie"] ?? "",
//     bAdharcard: json["b_adharcard"] ?? "",
//     bLicense: json["b_license"] ?? "",
//     bBikeName: json["b_bike_name"] ?? ""
//     );
//   }
// }




class NotificationModel {
   int? nId;
   int? userId;
   int? adminId;
   String? role;
   String? type;
   String? message;
   String? status;

  NotificationModel({
     this.nId,
     this.userId,
     this.adminId,
     this.role,
     this.type,
     this.message,
     this.status,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      nId: json['n_id'] ?? 0,
      userId: json['user_id'] ?? 0,
      adminId: json['admin_id'] ?? 0,
      role: json['role'] ?? '',
      type: json['type'] ?? '',
      message: json['message'] ?? '',
      status: json['status'] ?? '',
    );
  }
}


// user model




class UserModel {
    int? uId;
    String? uName;
    String? uEmail;
    String? uPassword;
    int? uMobile;
    String? uAddress;
    String? uState;
    String? uDistrict;
    int? uPincode;
    DateTime? uJoindate;
    String? uRole;
    int? uToken;
    dynamic uTokenExpiry;
    String? uOtpStatus;
    String? uProfilePic;
    String? uAdharcard;
    String? uLicense;
  String? uDob;


    UserModel({
        this.uId,
        this.uName,
        this.uEmail,
        this.uPassword,
        this.uMobile,
        this.uAddress,
        this.uState,
        this.uDistrict,
        this.uPincode,
        this.uJoindate,
        this.uRole,
        this.uToken,
        this.uTokenExpiry,
        this.uOtpStatus,
        this.uProfilePic,
        this.uAdharcard,
        this.uLicense,
        this.uDob
    });

    factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uId: json["u_id"],
        uName: json["u_name"],
        uEmail: json["u_email"],
        uPassword: json["u_password"],
        uMobile: json["u_mobile"],
        uAddress: json["u_address"],
        uState: json["u_state"],
        uDistrict: json["u_district"],
        uPincode: json["u_pincode"],
        uJoindate: DateTime.parse(json["u_joindate"]),
        uRole: json["u_role"],
        uToken: json["u_token"],
        uTokenExpiry: json["u_token_expiry"],
        uOtpStatus: json["u_otp_status"],
        uProfilePic: json["u_profile_pic"],
        uAdharcard: json["u_adharcard"],
        uLicense: json["u_license"],
         uDob: json["u_dob"] ?? "",
    );
}


class SupportModel {
    int cId;
    String cName;
    String cEmail;
    int cPhonenumber;
    String cIssuetype;
    String cMessage;
    String cImage;

    SupportModel({
        required this.cId,
        required this.cName,
        required this.cEmail,
        required this.cPhonenumber,
        required this.cIssuetype,
        required this.cMessage,
        required this.cImage,
    });

    factory SupportModel.fromJson(Map<String, dynamic> json) => SupportModel(
        cId: json["c_id"] ?? "",
        cName: json["c_name"] ??" ",
        cEmail: json["c_email"] ?? "",
        cPhonenumber: json["c_phonenumber"] ??"",
        cIssuetype: json["c_issuetype"] ?? "",
        cMessage: json["c_message"] ?? "",
        cImage: json["c_image"] ?? "",
    );
}

class BikeCenters{
    int lId;
    String lLocation;
    String lDistrict;

    BikeCenters({
        required this.lId,
       required this.lLocation,
        required this.lDistrict,
    });

    factory BikeCenters.fromJson(Map<String, dynamic> json) => BikeCenters(
        lId: json["l_id"] ?? "",
        lLocation: json["l_location"] ?? "",
        lDistrict: json["l_district"] ?? "",
    );
}