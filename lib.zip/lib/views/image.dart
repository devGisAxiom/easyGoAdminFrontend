import 'package:flutter/material.dart';

class ImageView extends StatelessWidget {
  String image ;
   ImageView({required this.image , super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(child: Image.network("https://lunarsenterprises.com:6032/$image")),
      ),
    );
  }
}