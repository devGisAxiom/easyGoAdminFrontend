import 'package:flutter/material.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/insidepages/bikes.dart';
import 'package:getbike_admin/views/insidepages/bikesonride.dart';
import 'package:getbike_admin/views/insidepages/bookng_req.dart';
import 'package:getbike_admin/views/insidepages/cancellation_reqs.dart';
import 'package:getbike_admin/views/insidepages/cancelledrides.dart';
import 'package:getbike_admin/views/insidepages/completedrides.dart';
import 'package:getbike_admin/views/insidepages/contact_support.dart';
import 'package:getbike_admin/views/insidepages/dashborad.dart';
import 'package:getbike_admin/views/insidepages/extenaion_req.dart';
import 'package:getbike_admin/views/insidepages/feedback.dart';
import 'package:getbike_admin/views/insidepages/logout.dart';
import 'package:getbike_admin/views/insidepages/payments.dart';
import 'package:getbike_admin/views/insidepages/settings.dart';
import 'package:getbike_admin/views/insidepages/upcomingrides.dart';
import 'package:getbike_admin/views/insidepages/users.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sidebarx/sidebarx.dart';

class HomeScreen extends StatefulWidget {
  final int? navindex; // ✅ added like in LeftBar

  const HomeScreen({Key? key, this.navindex}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late SidebarXController _controller; // ✅ late initialization
  final _key = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();

    // ✅ initialize controller with passed navindex (like LeftBar)
    _controller = SidebarXController(
      selectedIndex: widget.navindex ?? 0,
      extended: true,
    );

    fetchAdmin();
  }

  String? adminName;
  String? adminEmail;

  Future<void> fetchAdmin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      adminName = prefs.getString('adminName') ?? "Admin";
      adminEmail = prefs.getString('adminEmail') ?? "admin@getbike.com";
    });
  }

  final List<String> labels = [
    "Dashboard",
    "Booking Requests",
    "Bikes Onride",
    "Upcoming Rides",
    "Completed Rides",
    "Cancelled Rides",
    "Extension Requests",
    "Cancellation Requests",
    "Users",
    "Feedback",
    "Payments",
    "Vehicles",
    "Settings",
    "Support",
    "Logout",
  ];

  final List<IconData> icons = [
    Icons.dashboard,
    Icons.assignment,
    Icons.directions_bike_rounded,
    Icons.access_time_rounded,
    Icons.check_box,
    Icons.error,
    Icons.update,
    Icons.close,
    Icons.people,
    Icons.bar_chart,
    // Icons.payment,
    Icons.directions_bike,
    Icons.settings,
    Icons.support,
    Icons.logout,
  ];

  final List<Widget> pages = [
    Dashborad(),
    BookingRequests(),
    BikesOnride(),
    Upcomingrides(),
    CompletedRides(),
    CancelledRides(),
    ExtensionRequests(),
    CancellationRequests(),
    UserListPage(),
    FeedbackPage(),
    // PaymentList(),
    VehiclesList(),
    // SettingsPage(),
    SupportPage(),
    Logout(),
  ];

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = MediaQuery.of(context).size.width < 700;

    return Scaffold(
      key: _key,
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Image.asset("assets/images/logogetbike.png", height: 40, width: 40),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                "GetBike Admin Panel",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.black),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.person, color: Colors.black54),
                  const SizedBox(width: 8),
                  Text(adminName ?? "Admin",
                      style: const TextStyle(color: Colors.black87, fontSize: 14)),
                ],
              ),
            )
          ],
        ),
        leading: isSmallScreen
            ? IconButton(
                icon: const Icon(Icons.menu, color: Colors.black),
                onPressed: () {
                  _key.currentState?.openDrawer();
                },
              )
            : null,
      ),
      drawer:
          isSmallScreen ? ExampleSidebarX(controller: _controller) : null,
      body: Row(
        children: [
          if (!isSmallScreen)
            ExampleSidebarX(controller: _controller),
          Expanded(
            child: Center(
              child: _ScreensExample(
                controller: _controller,
                pages: pages,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ExampleSidebarX extends StatelessWidget {
  const ExampleSidebarX({Key? key, required SidebarXController controller})
      : _controller = controller,
        super(key: key);

  final SidebarXController _controller;

  @override
  Widget build(BuildContext context) {
    final List<String> labels = [
      "Dashboard",
      "Booking Requests",
      "Bikes Onride",
      "Upcoming Rides",
      "Completed Rides",
      "Cancelled Rides",
      "Extension Requests",
      "Cancellation Requests",
      "Users",
      "Feedback",
      // "Payments",
      "Vehicles",
      // "Settings",
      "Support",
      "Logout",
    ];

    final List<IconData> icons = [
      Icons.dashboard,
      Icons.assignment,
      Icons.directions_bike_rounded,
      Icons.access_time_rounded,
      Icons.check_box,
      Icons.error,
      Icons.update,
      Icons.close,
      Icons.people,
      Icons.bar_chart,
      // Icons.payment,
      Icons.directions_bike,
      // Icons.settings,/
      Icons.support,
      Icons.logout,
    ];

    return SidebarX(
      controller: _controller,
      theme: SidebarXTheme(
        margin: const EdgeInsets.all(10),
        decoration: const BoxDecoration(color: Colors.white),
        hoverColor: Colors.grey.shade200,
        textStyle: const TextStyle(color: Colors.black87),
        selectedTextStyle: const TextStyle(color: Colors.white),
        selectedItemDecoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(10),
        ),
        iconTheme: IconThemeData(color: Colors.black.withOpacity(0.7)),
        selectedIconTheme:
            const IconThemeData(color: Colors.white),
      ),
      extendedTheme: const SidebarXTheme(width: 250),
      items: List.generate(labels.length, (index) {
        return SidebarXItem(
          icon: icons[index],
          label: labels[index],
          onTap: () {
            if (labels[index] == "Logout") {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  title: const Text("Logout"),
                  content: const Text("Are you sure you want to logout?"),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _controller.selectIndex(0);
                      },
                      child: const Text("No"),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.pop(context);
                        SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        await prefs.clear();
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (_) => Logout()), // redirect to logout page
                          (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      child: const Text("Yes"),
                    ),
                  ],
                ),
              );
            }
          },
        );
      }),
    );
  }
}

class _ScreensExample extends StatelessWidget {
  const _ScreensExample({
    Key? key,
    required this.controller,
    required this.pages,
  }) : super(key: key);

  final SidebarXController controller;
  final List<Widget> pages;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        final index = controller.selectedIndex;
        if (index >= 0 && index < pages.length) {
          return pages[index];
        } else {
          return const Center(
            child: Text(
              "Page not found",
              style: TextStyle(fontSize: 20),
            ),
          );
        }
      },
    );
  }
}
