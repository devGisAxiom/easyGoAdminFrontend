import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/utilities.dart';

class FeedbackPage extends StatefulWidget {
  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  BikeController _bikeController = BikeController();
  TextEditingController _searchController = TextEditingController();
  List<BikeReviewModel> _allReviews = [];
  List<BikeReviewModel> _filteredReviews = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(_onSearchChanged);
  }

  Future<void> fetchdata() async {
    await _bikeController.fetchBikes();
    _allReviews = List.from(_bikeController.allReviews);
    _filteredReviews = List.from(_allReviews);
    setState(() {});
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredReviews = List.from(_allReviews);
      } else {
        _filteredReviews = _allReviews.where((review) {
          return (review.uName ?? "").toLowerCase().contains(query) ||
              (review.brBikeId?.toString() ?? "").contains(query) ||
              (review.brReview?.toLowerCase() ?? "").contains(query) ||
              _getBikeName(review.brBikeId).toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  String _getBikeName(int? bikeId) {
    if (bikeId == null) return 'Unknown';
    try {
      final bike = _bikeController.bikeList.firstWhere(
        (b) => b.bId == bikeId,
        orElse: () => BikeModel(
          bId: 0,
          bName: 'Unknown',
          bRatings: 0,
          bDescription: '',
          bPrice: 0,
          bStatus: '',
          bLocation: '',
          bExtras: '',
          bMilage: 0,
          bGeartype: '',
          bFueltype: '',
          bBhp: 0,
          bImage: '',
          bReviews: '',
          distance: 0,
          maxSpeed: 0,
          maintainceStatus: "",
          center: "",
          bikereviews: [],
          bikeimages: [],
        ),
      );
      return bike.bName;
    } catch (e) {
      return 'Unknown';
    }
  }

  Widget _buildRatingStars(double rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        return Icon(
          index < rating ? Icons.star : Icons.star_border,
          color: Colors.amber,
          size: 18,
        );
      }),
    );
  }

  Color _getRatingColor(double rating) {
    if (rating >= 4.0) return Colors.green;
    if (rating >= 3.0) return Colors.orange;
    return Colors.red;
  }

  void _showReviewDetails(BuildContext context, BikeReviewModel review) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Review Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Customer Name', review.uName ?? 'N/A'),
            _buildDetailRow('Bike Name', _getBikeName(review.brBikeId)),
            _buildDetailRow('Bike ID', review.brBikeId?.toString() ?? 'N/A'),
            SizedBox(height: 16),
            Text(
              'Rating:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                _buildRatingStars(review.brRating?.toDouble() ?? 0),
                SizedBox(width: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getRatingColor(review.brRating?.toDouble() ?? 0).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _getRatingColor(review.brRating?.toDouble() ?? 0)),
                  ),
                  child: Text(
                    '${review.brRating?.toStringAsFixed(1) ?? '0.0'}',
                    style: TextStyle(
                      color: _getRatingColor(review.brRating?.toDouble() ?? 0),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              'Review:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 8),
            Container(
              width: double.maxFinite,
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: Text(
                review.brReview ?? 'No review text',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[800],
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          OutlinedButton(
            onPressed: () {
              Navigator.pop(context);
              _confirmDeleteReview(context, review);
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.red,
              side: BorderSide(color: Colors.red),
            ),
            child: Text('Delete Review'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[800]),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteReview(BuildContext context, BikeReviewModel review) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Review'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to delete this review?'),
            SizedBox(height: 16),
            _buildDetailRow('Customer', review.uName ?? 'N/A'),
            _buildDetailRow('Bike', _getBikeName(review.brBikeId)),
            _buildDetailRow('Rating', '${review.brRating?.toString() ?? 'N/A'} stars'),
            SizedBox(height: 8),
            Text(
              'This action cannot be undone.',
              style: TextStyle(
                color: Colors.red[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteReview(review);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Delete Review'),
          ),
        ],
      ),
    );
  }

  void _deleteReview(BikeReviewModel review) {
    // TODO: Implement actual delete functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Review from ${review.uName} deleted'),
        backgroundColor: Colors.red,
      ),
    );
    // Remove from local list
    setState(() {
      _allReviews.removeWhere((r) => r.brId == review.brId);
      _filteredReviews.removeWhere((r) => r.brId == review.brId);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Customer Reviews & Feedback',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Reviews',
                hintText: 'Search by customer name, bike name, review text...',
                prefixIcon: Icon(Icons.search, color: primaryColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count and Stats
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredReviews.length} review(s)',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 50,
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal:  16.0),
                        child: Text('Bike ID'),
                      )),
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal:  16.0),
                      
                        child: Text('Bike Name'),
                      )),
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Text('Customer'),
                      )),
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal:  16.0),
                        child: Text('Rating'),
                      )),
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal:  16.0),
                        child: Text('Review'),
                      )),
                      DataColumn(label: Padding(
                        padding: EdgeInsets.symmetric(horizontal:  16.0),
                        child: Text('Actions'),
                      )),
                    ],
                    rows: _filteredReviews.map((review) {
                      return DataRow(
                        cells: [
                          DataCell(Text(
                            review.brBikeId?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(
                            _getBikeName(review.brBikeId),
                            style: TextStyle(fontWeight: FontWeight.w500),
                          )),
                          DataCell(Text(
                            review.uName ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w500),
                          )),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getRatingColor(review.brRating?.toDouble() ?? 0).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: _getRatingColor(review.brRating?.toDouble() ?? 0)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    review.brRating?.toString() ?? '0',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: _getRatingColor(review.brRating?.toDouble() ?? 0),
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(Icons.star, color: Colors.amber, size: 14),
                                ],
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              width: 300,
                              child: Text(
                                review.brReview ?? 'No review text',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 11),
                              ),
                            ),
                          ),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ElevatedButton(
                                  onPressed: () {
                                    _showReviewDetails(context, review);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('View'),
                                ),
                                SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: () {
                                    _confirmDeleteReview(context, review);
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red,
                                    side: BorderSide(color: Colors.red),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Delete'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}