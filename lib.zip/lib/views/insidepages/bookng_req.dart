import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:dio/dio.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/controllers_post/update_bike.dart';
import 'package:getbike_admin/controllers_post/updatestatus.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/image.dart';

class BookingRequests extends StatefulWidget {
  @override
  State<BookingRequests> createState() => _BookingRequestsState();
}

class _BookingRequestsState extends State<BookingRequests> {
  MyBookingController _bookingController = MyBookingController();
  TextEditingController _searchController = TextEditingController();
  final Dio _dio = Dio();

  List<BookingModel> _allBikes = [];
  List<BookingModel> _filteredBikes = [];
  Map<String, bool> _downloadingFiles = {};

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(() {
      _onSearchChanged(_searchController.text);
    });
  }

  Future<void> fetchdata() async {
    await _bookingController.fetchBikes();
    _allBikes = List.from(_bookingController.bookingReqList);
    _filteredBikes = List.from(_allBikes);
    setState(() {});
  }

  void _onSearchChanged(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredBikes = List.from(_allBikes);
      } else {
        _filteredBikes = _allBikes.where((bike) {
          final q = query.toLowerCase();
          return (bike.bType ?? "").toLowerCase().contains(q) ||
                 (bike.bId?.toString() ?? "").contains(q) ||
                 (bike.bUId?.toString() ?? "").contains(q) ||
                 (bike.bRole ?? "").toLowerCase().contains(q) ||
                 (bike.bPickupLocation ?? "").toLowerCase().contains(q) ||
                 (bike.bDropLocation ?? "").toLowerCase().contains(q);
        }).toList();
      }
    });
  }


  bool _isPdf(String? url) {
    if (url == null) return false;
    return url.toLowerCase().endsWith('.pdf');
  }

  Future<void> _downloadAndOpenPdf(String url, String fileName) async {
    print("Download URL: $url");
    
    try {
      // For Android 10+ (API 29+), we don't need storage permissions for app-specific directory
      final directory = await getApplicationDocumentsDirectory();
      final filePath = '${directory.path}/$fileName.pdf';

      setState(() {
        _downloadingFiles[url] = true;
      });

      // Download file
      await _dio.download(
        url,
        filePath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            print('Download progress: ${(received / total * 100).toStringAsFixed(0)}%');
          }
        },
      );

      setState(() {
        _downloadingFiles[url] = false;
      });

      // Open the file
      final result = await OpenFile.open(filePath);
      
      print("Open file result: ${result.message}");
      
      if (result.type != ResultType.done) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to open PDF: ${result.message}')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('PDF opened successfully')),
        );
      }

    } catch (e) {
      setState(() {
        _downloadingFiles[url] = false;
      });
      
      print("Download error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Download failed: ${e.toString()}')),
      );
    }
  }

  Future<void> _viewPdfOnline(String url) async {
    try {
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(
          Uri.parse(url),
          mode: LaunchMode.externalApplication,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch PDF viewer')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening PDF: $e')),
      );
    }
  }

  // Alternative simple download without permissions
  Future<void> _simpleDownloadPdf(String url, String documentType) async {
    try {
      setState(() {
        _downloadingFiles[url] = true;
      });

      // Just open the URL in browser for download
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(
          Uri.parse(url),
          mode: LaunchMode.externalApplication,
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Opening $documentType in browser...')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF')),
        );
      }

      setState(() {
        _downloadingFiles[url] = false;
      });
    } catch (e) {
      setState(() {
        _downloadingFiles[url] = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  Widget _buildDocumentWidget(String? documentUrl, String documentType) {
    final fullUrl = "https://lunarsenterprises.com:6032/${documentUrl ?? ''}";
    
    if (documentUrl == null || documentUrl.isEmpty) {
      return _buildPlaceholderIcon(Icons.document_scanner, 'No $documentType');
    }

    if (_isPdf(documentUrl)) {
      final isDownloading = _downloadingFiles[fullUrl] == true;
      
      return GestureDetector(
        onTap: () {
          _showPdfOptionsDialog(context, fullUrl, documentType);
        },
        child: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: isDownloading ? Colors.grey[300] : Colors.grey[100],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: isDownloading
              ? Center(
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
                  ),
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.picture_as_pdf, color: Colors.red, size: 24),
                    SizedBox(height: 4),
                    Text(
                      'PDF',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
        ),
      );
    } else {
      // It's an image
      return GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ImageView(image: documentUrl ?? ''),
            ),
          );
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              fullUrl,
              width: 50,
              height: 50,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildPlaceholderIcon(Icons.broken_image, 'Error');
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
      );
    }
  }

  void _showPdfOptionsDialog(BuildContext context, String url, String documentType) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$documentType Document'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.picture_as_pdf, size: 64, color: Colors.red),
            SizedBox(height: 16),
            Text(
              'Choose how you want to view the PDF:',
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          OutlinedButton(
            onPressed: () {
              Navigator.pop(context);
              _viewPdfOnline(url);
            },
            child: Text('View Online'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Use simple download that doesn't require permissions
              _simpleDownloadPdf(url, documentType);
            },
            child: Text('Download PDF'),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholderIcon(IconData icon, String tooltip) {
    return Tooltip(
      message: tooltip,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Icon(icon, color: Colors.grey, size: 24),
      ),
    );
  }


  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Booking Requests',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        children: [
          // Search Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Booking Requests',
                hintText: 'Search by bike name, ID, user, location...',
                prefixIcon: Icon(Icons.search, color: primaryColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBikes.length} booking request(s) found',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 16,
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('Req ID')),
                      DataColumn(label: Text('Date')),
                      DataColumn(label: Text('Bike Name')),
                      DataColumn(label: Text('Bike ID')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('User ID')),
                      DataColumn(label: Text('Days')),
                      DataColumn(label: Text('Amount')),
                      DataColumn(label: Text('Pickup Location')),
                      DataColumn(label: Text('Pickup Date & Time')),
                      DataColumn(label: Text('Drop Location')),
                      DataColumn(label: Text('Drop Date & Time')),
                      DataColumn(label: Text('Rent')),
                      DataColumn(label: Text('Payment Status')),
                      DataColumn(label: Text('User Image')),
                      DataColumn(label: Text('License')),
                      DataColumn(label: Text('Aadhaar')),
                      DataColumn(label: Text('Invoice')),
                      DataColumn(label: Text('Status')),
                    ],
                    rows: _filteredBikes.map((booking) {
                      // ... (keep your existing date parsing logic)
                      DateTime? pickupDateTime;
                      DateTime? dropDateTime;
                      int? noOfDays;

                      try {
                        if (booking.bPickupDate != null &&
                            booking.bPicupTime != null &&
                            booking.bDropDate != null &&
                            booking.bDropTime != null) {
                          
                          DateTime pickupDate = DateTime.parse(booking.bPickupDate);
                          DateTime dropDate   = DateTime.parse(booking.bDropDate);

                          List<String> pickupTimeParts = booking.bPicupTime.split(":");
                          List<String> dropTimeParts   = booking.bDropTime.split(":");

                          pickupDateTime = DateTime(
                            pickupDate.year,
                            pickupDate.month,
                            pickupDate.day,
                            int.parse(pickupTimeParts[0]),
                            int.parse(pickupTimeParts[1]),
                            pickupTimeParts.length > 2 ? int.parse(pickupTimeParts[2]) : 0,
                          );

                          dropDateTime = DateTime(
                            dropDate.year,
                            dropDate.month,
                            dropDate.day,
                            int.parse(dropTimeParts[0]),
                            int.parse(dropTimeParts[1]),
                            dropTimeParts.length > 2 ? int.parse(dropTimeParts[2]) : 0,
                          );

                          noOfDays = dropDateTime.difference(pickupDateTime).inDays;
                          if (noOfDays <= 0) {
                            noOfDays = 1;
                          }
                        }
                      } catch (e) {
                        noOfDays = null;
                      }

                      Color statusColor = Colors.grey;
                      if (booking.bStatus?.toLowerCase() == 'approved') {
                        statusColor = Colors.green;
                      } else if (booking.bStatus?.toLowerCase() == 'rejected') {
                        statusColor = Colors.red;
                      } else if (booking.bStatus?.toLowerCase() == 'pending') {
                        statusColor = Colors.orange;
                      }

                      return DataRow(
                        cells: [
                          DataCell(Text(
                            booking.bId?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(booking.bookingDate?.toString() ?? '-')),
                          DataCell(Text(booking.bBikeName ?? '-')),
                          DataCell(Text(booking.bBkId?.toString() ?? '-')),
                          DataCell(Text(booking.uName?.toString() ?? '-')),
                          DataCell(Text(booking.bUId?.toString() ?? '-')),
                          DataCell(Center(child: Text(noOfDays?.toString() ?? '1'))),
                          DataCell(Text(
                            booking.bPrice?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bPickupLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Text(
                              '${booking.bPickupDate ?? ''} ${booking.bPicupTime ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bDropLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Text(
                              '${booking.bDropDate ?? ''} ${booking.bDropTime ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Text(booking.bPrice?.toString() ?? '-')),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getPaymentStatusColor(booking.bPaymentStatus),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                booking.bPaymentStatus?.toUpperCase() ?? 'PENDING',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          DataCell(_buildDocumentWidget(booking.bSelfie, 'User Image')),
                          DataCell(_buildDocumentWidget(booking.bLicense, 'License')),
                          DataCell(_buildDocumentWidget(booking.bAdharcard, 'Aadhaar')),
                          DataCell(_buildDocumentWidget(booking.invoice, 'Invoice')),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (booking.bStatus?.toLowerCase() != 'approved')
                                  ElevatedButton(
                                    onPressed: () {
                                      updatebookingstatus(
                                        context, 
                                        booking.bUId.toString(), 
                                        "approved", 
                                        booking.bId.toString(),
                                        1
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green,
                                      foregroundColor: Colors.white,
                                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      textStyle: TextStyle(fontSize: 12),
                                    ),
                                    child: const Text('Accept'),
                                  ),
                                if (booking.bStatus?.toLowerCase() != 'rejected') ...[
                                  SizedBox(width: 6),
                                  ElevatedButton(
                                    onPressed: () {
                                      updatebookingstatus(
                                        context, 
                                        booking.bUId.toString(), 
                                        "rejected", 
                                        booking.bId.toString(),
                                        1
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red,
                                      foregroundColor: Colors.white,
                                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      textStyle: TextStyle(fontSize: 12),
                                    ),
                                    child: const Text('Reject'),
                                  ),
                                ],
                                if (booking.bStatus?.toLowerCase() == 'approved' || 
                                    booking.bStatus?.toLowerCase() == 'rejected')
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: statusColor.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: statusColor),
                                    ),
                                    child: Text(
                                      booking.bStatus?.toUpperCase() ?? '',
                                      style: TextStyle(
                                        color: statusColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getPaymentStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'paid':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'failed':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}