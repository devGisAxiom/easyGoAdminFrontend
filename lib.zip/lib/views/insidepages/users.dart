import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/image.dart';
import 'package:url_launcher/url_launcher.dart';

class UserListPage extends StatefulWidget {
  @override
  State<UserListPage> createState() => _UserListPageState();
}

class _UserListPageState extends State<UserListPage> {
  UserController _userController = UserController();
  TextEditingController _searchController = TextEditingController();
  List<UserModel> _users = [];
  List<UserModel> _filteredUsers = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(_onSearchChanged);
  }

  Future<void> fetchdata() async {
    await _userController.fetchuser();
    _users = List.from(_userController.userList);
    _filteredUsers = List.from(_users);
    setState(() {});
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredUsers = List.from(_users);
      } else {
        _filteredUsers = _users.where((user) {
          return (user.uName ?? "").toLowerCase().contains(query) ||
              (user.uId?.toString() ?? "").contains(query) ||
              (user.uEmail ?? "").toLowerCase().contains(query) ||
              (user.uMobile?.toString() ?? "").contains(query);
        }).toList();
      }
    });
  }

  // Format date if available
  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return '-';
    
    try {
      final date = DateTime.parse(dateString);
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      final day = date.day;
      final month = months[date.month - 1];
      final year = date.year;
      
      return '$day $month $year';
    } catch (e) {
      return dateString;
    }
  }

  bool _isPdf(String? url) {
    if (url == null) return false;
    return url.toLowerCase().endsWith('.pdf');
  }

  Future<void> _openPdf(String url, String documentType) async {
    try {
      final fullUrl = url.startsWith('http') ? url : "https://lunarsenterprises.com:6032/$url";
      if (await canLaunchUrl(Uri.parse(fullUrl))) {
        await launchUrl(
          Uri.parse(fullUrl),
          mode: LaunchMode.externalApplication,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening PDF: ${e.toString()}')),
      );
    }
  }

  Widget _buildDocumentWidget(String? documentUrl, String documentType) {
    final fullUrl = documentUrl?.startsWith('http') == true 
        ? documentUrl 
        : "https://lunarsenterprises.com:6032/${documentUrl ?? ''}";
    
    if (documentUrl == null || documentUrl.isEmpty) {
      return _buildPlaceholderIcon(Icons.document_scanner, 'No $documentType');
    }

    if (_isPdf(documentUrl)) {
      return GestureDetector(
        onTap: () {
          _openPdf(documentUrl, documentType);
        },
        child: Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.picture_as_pdf, color: Colors.red, size: 24),
              SizedBox(height: 4),
              Text(
                'PDF',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      return GestureDetector(
        onTap: () {
          Navigations.push(ImageView(image: documentUrl), context);
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              fullUrl ?? '',
              width: 60,
              height: 60,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildPlaceholderIcon(Icons.broken_image, 'Error');
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
      );
    }
  }

  Widget _buildPlaceholderIcon(IconData icon, String tooltip) {
    return Tooltip(
      message: tooltip,
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Icon(icon, color: Colors.grey, size: 24),
      ),
    );
  }

  void _showUserDetails(BuildContext context, UserModel user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('User Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('User ID', user.uId?.toString() ?? 'N/A'),
            _buildDetailRow('Name', user.uName ?? 'N/A'),
            _buildDetailRow('Email', user.uEmail ?? 'N/A'),
            _buildDetailRow('Phone', user.uMobile?.toString() ?? 'N/A'),
            _buildDetailRow('Date of Birth', _formatDate(user.uDob)),
            SizedBox(height: 16),
            Text(
              'Document Status:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            _buildDetailRow('License', user.uLicense != null ? 'Uploaded' : 'Not Uploaded'),
            _buildDetailRow('Aadhaar', user.uAdharcard != null ? 'Uploaded' : 'Not Uploaded'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          if (user.uMobile != null)
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _makePhoneCall(user.uMobile.toString());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
              child: Text('Call User'),
            ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[800]),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    try {
      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch phone app')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error making call: ${e.toString()}')),
      );
    }
  }

  void _showAddUserDialog(BuildContext context) {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();
    final dobController = TextEditingController();
    final licenseController = TextEditingController();
    final aadharController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add New User'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController, 
                decoration: InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                )
              ),
              SizedBox(height: 12),
              TextField(
                controller: emailController, 
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                )
              ),
              SizedBox(height: 12),
              TextField(
                controller: phoneController, 
                decoration: InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(),
                )
              ),
              SizedBox(height: 12),
              TextField(
                controller: dobController, 
                decoration: InputDecoration(
                  labelText: 'DOB (YYYY-MM-DD)',
                  border: OutlineInputBorder(),
                )
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
             
            },
            child: Text('Add'),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteUser(BuildContext context, UserModel user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete User'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to delete this user?'),
            SizedBox(height: 16),
            _buildDetailRow('Name', user.uName ?? 'N/A'),
            _buildDetailRow('Email', user.uEmail ?? 'N/A'),
            _buildDetailRow('User ID', user.uId?.toString() ?? 'N/A'),
            SizedBox(height: 8),
            Text(
              'This action cannot be undone.',
              style: TextStyle(
                color: Colors.red[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteUser(user);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Delete User'),
          ),
        ],
      ),
    );
  }

  void _deleteUser(UserModel user) {
    // TODO: Implement actual delete functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("User ${user.uName} deleted")),
    );
    fetchdata();
  }

  void _addUser(BuildContext context) {
    _showAddUserDialog(context);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'User Management',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search and Add User Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      labelText: 'Search Users',
                      hintText: 'Search by name, email, phone, ID...',
                      prefixIcon: Icon(Icons.search, color: primaryColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey[400]!),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: primaryColor, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                ),
                // SizedBox(width: 16),
                // ElevatedButton.icon(
                //   onPressed: () => _addUser(context),
                //   icon: Icon(Icons.person_add, size: 20),
                //   label: Text('Add User'),
                //   style: ElevatedButton.styleFrom(
                //     backgroundColor: primaryColor,
                //     foregroundColor: Colors.white,
                //     padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                //   ),
                // ),
              ],
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredUsers.length} user(s) found',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 40, // Increased from 20 to 40
                    horizontalMargin: 24, // Increased from 16 to 24
                    headingRowHeight: 60, // Increased row height
                    dataRowMinHeight: 70, // Increased row height
                    dataRowMaxHeight: 80, // Increased row height
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 13, // Slightly larger font
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 13, // Slightly larger font
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('User ID'), numeric: true),
                      DataColumn(label: Text('Name')),
                      DataColumn(label: Text('Email')),
                      DataColumn(label: Text('Phone'), numeric: true),
                      DataColumn(label: Text('Date of Birth')),
                      DataColumn(label: Text('License')),
                      DataColumn(label: Text('Aadhaar')),
                      DataColumn(label: Text('Profile')),
                      DataColumn(label: Text('Actions')),
                    ],
                    rows: _filteredUsers.map((user) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                user.uId?.toString() ?? '-',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                user.uName ?? '-',
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              width: 180, // Increased width
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                user.uEmail ?? '-',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                user.uMobile?.toString() ?? '-',
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                _formatDate(user.uDob),
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: _buildDocumentWidget(user.uLicense, 'License'),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: _buildDocumentWidget(user.uAdharcard, 'Aadhaar'),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: _buildDocumentWidget(user.uProfilePic, 'Profile'),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ElevatedButton(
                                    onPressed: () {
                                      _showUserDetails(context, user);
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      foregroundColor: Colors.white,
                                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), // Increased padding
                                      textStyle: TextStyle(
                                        fontSize: 12, // Slightly larger
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    child: Text('Details'),
                                  ),
                                  SizedBox(width: 12), // Increased spacing
                                  if (user.uMobile != null)
                                    ElevatedButton(
                                      onPressed: () {
                                        _makePhoneCall(user.uMobile.toString());
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), // Increased padding
                                        textStyle: TextStyle(
                                          fontSize: 12, // Slightly larger
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      child: Text('Call'),
                                    ),
                                  SizedBox(width: 12), // Increased spacing
                                  OutlinedButton(
                                    onPressed: () {
                                      _confirmDeleteUser(context, user);
                                    },
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: Colors.red,
                                      side: BorderSide(color: Colors.red),
                                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), // Increased padding
                                      textStyle: TextStyle(
                                        fontSize: 12, // Slightly larger
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    child: Text('Delete'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}