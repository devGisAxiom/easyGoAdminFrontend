import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/controllers_post/updatestatus.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:url_launcher/url_launcher.dart';

class ExtensionRequests extends StatefulWidget {
  @override
  State<ExtensionRequests> createState() => _ExtensionRequestsState();
}

class _ExtensionRequestsState extends State<ExtensionRequests> {
  MyBookingController _bookingController = MyBookingController();
  TextEditingController _searchController = TextEditingController();
  List<BookingModel> _allBikes = [];
  List<BookingModel> _filteredBikes = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(_onSearchChanged);
  }

  Future<void> fetchdata() async {
    await _bookingController.fetchBikes();
    _allBikes = List.from(_bookingController.Extendbookingreq);
    _filteredBikes = List.from(_allBikes);
    setState(() {});
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredBikes = List.from(_allBikes);
      } else {
        _filteredBikes = _allBikes.where((booking) {
          return (booking.bBikeName ?? "").toLowerCase().contains(query) ||
              (booking.bId?.toString() ?? "").contains(query) ||
              (booking.bUId?.toString() ?? "").contains(query) ||
              (booking.uName ?? "").toLowerCase().contains(query) ||
              (booking.bPickupLocation ?? "").toLowerCase().contains(query) ||
              (booking.bDropLocation ?? "").toLowerCase().contains(query) ||
              ((booking.bPickupDate ?? "") + " " + (booking.bPicupTime ?? "")).toLowerCase().contains(query) ||
              ((booking.bDropDate ?? "") + " " + (booking.bDropTime ?? "")).toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  // Format date from "2025-09-11" to "11 Sep 2025"
  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return '-';
    
    try {
      final date = DateTime.parse(dateString);
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      final day = date.day;
      final month = months[date.month - 1];
      final year = date.year;
      
      return '$day $month $year';
    } catch (e) {
      return dateString; // Return original if parsing fails
    }
  }

  // Format time from "09:11:00" to "09:11 AM"
  String _formatTime(String? timeString) {
    if (timeString == null || timeString.isEmpty) return '-';
    
    try {
      final parts = timeString.split(':');
      if (parts.length >= 2) {
        final hour = int.parse(parts[0]);
        final minute = parts[1];
        final period = hour >= 12 ? 'PM' : 'AM';
        final displayHour = hour % 12 == 0 ? 12 : hour % 12;
        
        return '$displayHour:$minute $period';
      }
      return timeString;
    } catch (e) {
      return timeString; // Return original if parsing fails
    }
  }

  void _showCustomerDetails(BuildContext context, BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Extension Request Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Customer Name', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike Name', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Booking ID', booking.bId?.toString() ?? 'N/A'),
            _buildDetailRow('User ID', booking.bUId?.toString() ?? 'N/A'),
            SizedBox(height: 16),
            Text(
              'Original Drop-off:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            _buildDetailRow('Date', _formatDate(booking.bDropDate)),
            _buildDetailRow('Time', _formatTime(booking.bDropTime)),
            SizedBox(height: 8),
            Text(
              'Extended Drop-off:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.orange[700],
              ),
            ),
            _buildDetailRow('Date', _formatDate(booking.bDropDate)),
            _buildDetailRow('Time', _formatTime(booking.bDropDate)),
            SizedBox(height: 8),
            _buildDetailRow(' Rent', '₹${booking.bRentAmount?.toString() ?? '0'}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          if (booking.uMobile != null && booking.uMobile.toString().isEmpty)
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _makePhoneCall(booking.uMobile.toString());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
              child: Text('Call Customer'),
            ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[800]),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    try {
      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch phone app')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error making call: ${e.toString()}')),
      );
    }
  }

  void _confirmApproveExtension(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Approve Extension'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to approve this extension request?'),
            SizedBox(height: 16),
            _buildDetailRow('Customer', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Extended Date', _formatDate(booking.bDropDate)),
            _buildDetailRow('Extended Time', _formatTime(booking.bDropTime)),
            _buildDetailRow(' Rent', '₹${booking.bRentAmount?.toString() ?? '0'}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _approveExtension(booking);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
            ),
            child: Text('Approve Extension'),
          ),
        ],
      ),
    );
  }

  void _confirmRejectExtension(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Reject Extension'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to reject this extension request?'),
            SizedBox(height: 16),
            _buildDetailRow('Customer', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Extended Date', _formatDate(booking.bDropDate)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _rejectExtension(booking);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Reject Extension'),
          ),
        ],
      ),
    );
  }

  void _approveExtension(BookingModel booking) {
    // TODO: Implement extension approval logic
    updatebookingstatus(
      context, 
      booking.bUId.toString(), 
      "extended", 
      booking.bId.toString(), 
      4 // Assuming 4 is for extension approval
    );
    // .then((_) {
    //   ScaffoldMessenger.of(context).showSnackBar(
    //     SnackBar(content: Text('Extension approved successfully')),
    //   );
      fetchdata();
    // });
  }

  void _rejectExtension(BookingModel booking) {
    // TODO: Implement extension rejection logic
    updatebookingstatus(
      context, 
      booking.bUId.toString(), 
      "extension_rejected", 
      booking.bId.toString(), 
      4 // Assuming 4 is for extension actions
    );
    // .then((_) {
    //   ScaffoldMessenger.of(context).showSnackBar(
    //     SnackBar(content: Text('Extension request rejected')),
    //   );
      fetchdata();
    // });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Extension Requests',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        children: [
          // Search Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Extension Requests',
                hintText: 'Search by bike name, ID, user, location...',
                prefixIcon: Icon(Icons.search, color: primaryColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBikes.length} extension request(s)',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 16,
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('Req ID')),
                      DataColumn(label: Text('Bike Name')),
                      DataColumn(label: Text('Bike ID')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('User ID')),
                      DataColumn(label: Text('Pickup Location')),
                      DataColumn(label: Text('Original Drop-off')),
                      DataColumn(label: Text('Extended Drop-off')),
                      DataColumn(label: Text('Additional Rent')),
                      DataColumn(label: Text('Actions')),
                    ],
                    rows: _filteredBikes.map((booking) {
                      return DataRow(
                        cells: [
                          DataCell(Text(
                            booking.bId?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(
                            booking.bBikeName ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(booking.bBkId?.toString() ?? '-')),
                          DataCell(Text(
                            booking.uName ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w500),
                          )),
                          DataCell(Text(booking.bUId?.toString() ?? '-')),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bPickupLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bDropDate),
                                  style: TextStyle(fontSize: 11),
                                ),
                                Text(
                                  _formatTime(booking.bDropTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bDropDate),
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.orange[700],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  _formatTime(booking.bDropTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.orange[600],
                                  ),
                                ),
                              ],
                            ),
                          )),
                          DataCell(Text(
                            '₹${booking.bRentAmount?.toString() ?? '0'}',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.green[700],
                            ),
                          )),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ElevatedButton(
                                  onPressed: () {
                                    _showCustomerDetails(context, booking);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Details'),
                                ),
                                SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: () {
                                    _confirmApproveExtension(booking);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Approve'),
                                ),
                                SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: () {
                                    _confirmRejectExtension(booking);
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red,
                                    side: BorderSide(color: Colors.red),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Reject'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}