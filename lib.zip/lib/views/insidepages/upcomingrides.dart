import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/controllers_post/updatestatus.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/image.dart';
import 'package:url_launcher/url_launcher.dart';

class Upcomingrides extends StatefulWidget {
  @override
  State<Upcomingrides> createState() => _UpcomingridesState();
}

class _UpcomingridesState extends State<Upcomingrides> {
  MyBookingController _bookingController = MyBookingController();
  TextEditingController _searchController = TextEditingController();

  List<BookingModel> _allBikes = [];
  List<BookingModel> _filteredBikes = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(() {
      _onSearchChanged(_searchController.text);
    });
  }

  Future<void> fetchdata() async {
    await _bookingController.fetchBikes();
    _allBikes = List.from(_bookingController.upcomingList);
    _filteredBikes = List.from(_allBikes);
    setState(() {});
  }

  void _onSearchChanged(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredBikes = List.from(_allBikes);
      } else {
        _filteredBikes = _allBikes.where((bike) {
          final q = query.toLowerCase();
          return (bike.bBikeName ?? "").toLowerCase().contains(q) ||
                 (bike.bId?.toString() ?? "").contains(q) ||
                 (bike.bUId?.toString() ?? "").contains(q) ||
                 (bike.uName ?? "").toLowerCase().contains(q) ||
                 (bike.bPickupLocation ?? "").toLowerCase().contains(q) ||
                 (bike.bDropLocation ?? "").toLowerCase().contains(q);
        }).toList();
      }
    });
  }

  // Format date from "2025-09-11" to "11 Sep 2025"
  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return '-';
    
    try {
      final date = DateTime.parse(dateString);
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      final day = date.day;
      final month = months[date.month - 1];
      final year = date.year;
      
      return '$day $month $year';
    } catch (e) {
      return dateString; // Return original if parsing fails
    }
  }

  // Format time from "09:11:00" to "09:11 AM"
  String _formatTime(String? timeString) {
    if (timeString == null || timeString.isEmpty) return '-';
    
    try {
      final parts = timeString.split(':');
      if (parts.length >= 2) {
        final hour = int.parse(parts[0]);
        final minute = parts[1];
        final period = hour >= 12 ? 'PM' : 'AM';
        final displayHour = hour % 12 == 0 ? 12 : hour % 12;
        
        return '$displayHour:$minute $period';
      }
      return timeString;
    } catch (e) {
      return timeString; // Return original if parsing fails
    }
  }

  bool _isPdf(String? url) {
    if (url == null) return false;
    return url.toLowerCase().endsWith('.pdf');
  }

  Future<void> _openPdf(String url, String documentType) async {
    try {
      final fullUrl = url.startsWith('http') ? url : "https://lunarsenterprises.com:6032/$url";
      if (await canLaunchUrl(Uri.parse(fullUrl))) {
        await launchUrl(
          Uri.parse(fullUrl),
          mode: LaunchMode.externalApplication,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening PDF: ${e.toString()}')),
      );
    }
  }

  Widget _buildDocumentWidget(String? documentUrl, String documentType) {
    final fullUrl = documentUrl?.startsWith('http') == true 
        ? documentUrl 
        : "https://lunarsenterprises.com:6032/${documentUrl ?? ''}";
    
    if (documentUrl == null || documentUrl.isEmpty) {
      return _buildPlaceholderIcon(Icons.document_scanner, 'No $documentType');
    }

    if (_isPdf(documentUrl)) {
      return GestureDetector(
        onTap: () {
          _openPdf(documentUrl, documentType);
        },
        child: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.picture_as_pdf, color: Colors.red, size: 24),
              SizedBox(height: 4),
              Text(
                'PDF',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      // It's an image
      return GestureDetector(
        onTap: () {
          Navigations.push(ImageView(image: documentUrl), context);
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              fullUrl ?? '',
              width: 50,
              height: 50,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildPlaceholderIcon(Icons.broken_image, 'Error');
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
      );
    }
  }

  Widget _buildPlaceholderIcon(IconData icon, String tooltip) {
    return Tooltip(
      message: tooltip,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Icon(icon, color: Colors.grey, size: 24),
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'on ride':
        return Colors.blue;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      case 'upcoming':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  void _confirmBikePicked(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirm Bike Pickup'),
        content: Text('Are you sure the customer has picked up the bike?\n\n'
            'Bike: ${booking.bType ?? 'N/A'}\n'
            'User: ${booking.bRole ?? 'N/A'}\n'
            'Booking ID: ${booking.bId ?? 'N/A'}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              updatebookingstatus(
                context, 
                booking.bUId.toString(), 
                "onride", 
                booking.bId.toString(),
                3
              );
              fetchdata();
              //.then((_) {
              //   // Refresh the list after status update
              //   Future.delayed(Duration(seconds: 1), () {
              //     fetchdata();
              //   });
              // });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
            ),
            child: Text('Confirm Pickup', style: smalltextwhite,),
          ),
        ],
      ),
    );
  }

  void _confirmCancelRide(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Cancel Ride'),
        content: Text('Are you sure you want to cancel this ride?\n\n'
            'Bike: ${booking.bBikeName ?? 'N/A'}\n'
            'User: ${booking.uName ?? 'N/A'}\n'
            'Booking ID: ${booking.bId ?? 'N/A'}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('No'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              updatebookingstatus(
                context, 
                booking.bUId.toString(), 
                "cancelled", 
                booking.bId.toString(),
                3
              );
              fetchdata();
              // then((_) {
              //   // Refresh the list after cancellation
              //   Future.delayed(Duration(seconds: 1), () {
              //     fetchdata();
              //   });
              // });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Yes, Cancel'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Upcoming Rides',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        children: [
          // Search Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Upcoming Rides',
                hintText: 'Search by bike name, ID, user, location...',
                prefixIcon: Icon(Icons.search, color: primaryColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBikes.length} upcoming ride(s)',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 16,
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('Req ID')),
                      DataColumn(label: Text('Date')),
                      DataColumn(label: Text('Bike Name')),
                      DataColumn(label: Text('Bike ID')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('User ID')),
                      DataColumn(label: Text('Days')),
                      DataColumn(label: Text('Amount')),
                      DataColumn(label: Text('Pickup Location')),
                      DataColumn(label: Text('Pickup Date & Time')),
                      DataColumn(label: Text('Drop Location')),
                      DataColumn(label: Text('Drop Date & Time')),
                      DataColumn(label: Text('Rent')),
                      DataColumn(label: Text('User Image')),
                      DataColumn(label: Text('License')),
                      DataColumn(label: Text('Aadhaar')),
                      // DataColumn(label: Text('Invoice')),
                      DataColumn(label: Text('Status')),
                      DataColumn(label: Text('Actions')),
                    ],
                    rows: _filteredBikes.map((booking) {
                      DateTime? pickupDateTime;
                      DateTime? dropDateTime;
                      int? noOfDays;

                      try {
                        if (booking.bPickupDate != null &&
                            booking.bPicupTime != null &&
                            booking.bDropDate != null &&
                            booking.bDropTime != null) {
                          
                          DateTime pickupDate = DateTime.parse(booking.bPickupDate);
                          DateTime dropDate   = DateTime.parse(booking.bDropDate);

                          List<String> pickupTimeParts = booking.bPicupTime.split(":");
                          List<String> dropTimeParts   = booking.bDropTime.split(":");

                          pickupDateTime = DateTime(
                            pickupDate.year,
                            pickupDate.month,
                            pickupDate.day,
                            int.parse(pickupTimeParts[0]),
                            int.parse(pickupTimeParts[1]),
                            pickupTimeParts.length > 2 ? int.parse(pickupTimeParts[2]) : 0,
                          );

                          dropDateTime = DateTime(
                            dropDate.year,
                            dropDate.month,
                            dropDate.day,
                            int.parse(dropTimeParts[0]),
                            int.parse(dropTimeParts[1]),
                            dropTimeParts.length > 2 ? int.parse(dropTimeParts[2]) : 0,
                          );

                          noOfDays = dropDateTime.difference(pickupDateTime).inDays;
                          if (noOfDays <= 0) {
                            noOfDays = 1;
                          }
                        }
                      } catch (e) {
                        noOfDays = null;
                      }

                      // Check if pickup is today or upcoming
                      bool isPickupToday = false;
                      bool isPickupSoon = false;
                      if (pickupDateTime != null) {
                        final now = DateTime.now();
                        final today = DateTime(now.year, now.month, now.day);
                        final pickupDay = DateTime(pickupDateTime.year, pickupDateTime.month, pickupDateTime.day);
                        
                        isPickupToday = pickupDay == today;
                        isPickupSoon = pickupDay.isBefore(today.add(Duration(days: 3))) && pickupDay.isAfter(today);
                      }

                      return DataRow(
                        cells: [
                          DataCell(Text(
                            booking.bId?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(_formatDate(booking.bookingDate))),
                          DataCell(Text(booking.bBikeName ?? '-')),
                          DataCell(Text(booking.bBkId?.toString() ?? '-')),
                          DataCell(Text(booking.uName ?? '-')),
                          DataCell(Text(booking.bUId?.toString() ?? '-')),
                          DataCell(Center(
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.blue),
                              ),
                              child: Text(
                                noOfDays?.toString() ?? '1',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          )),
                          DataCell(Text(
                            '₹${booking.bPrice?.toString() ?? '-'}',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.green[700],
                            ),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bPickupLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bPickupDate),
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: isPickupToday ? Colors.green : (isPickupSoon ? Colors.orange : null),
                                    fontWeight: isPickupToday ? FontWeight.bold : FontWeight.normal,
                                  ),
                                ),
                                Text(
                                  _formatTime(booking.bPicupTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: isPickupToday ? Colors.green : (isPickupSoon ? Colors.orange : Colors.grey[600]),
                                  ),
                                ),
                                if (isPickupToday)
                                  Text(
                                    'TODAY',
                                    style: TextStyle(
                                      fontSize: 8,
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                if (isPickupSoon && !isPickupToday)
                                  Text(
                                    'SOON',
                                    style: TextStyle(
                                      fontSize: 8,
                                      color: Colors.orange,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                              ],
                            ),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bDropLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bDropDate),
                                  style: TextStyle(fontSize: 11),
                                ),
                                Text(
                                  _formatTime(booking.bDropTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          )),
                          DataCell(Text(
                            '₹${booking.bPrice?.toString() ?? '-'}',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(_buildDocumentWidget(booking.bSelfie, 'User Image')),
                          DataCell(_buildDocumentWidget(booking.bLicense, 'License')),
                          DataCell(_buildDocumentWidget(booking.bAdharcard, 'Aadhaar')),
                          // DataCell(_buildDocumentWidget(booking.invoice, 'Invoice')),
                          DataCell(
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: _getStatusColor(booking.bStatus).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: _getStatusColor(booking.bStatus)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.schedule,
                                    size: 16,
                                    color: _getStatusColor(booking.bStatus),
                                  ),
                                  SizedBox(width: 6),
                                  Text(
                                    booking.bStatus?.toUpperCase() ?? 'UPCOMING',
                                    style: TextStyle(
                                      color: _getStatusColor(booking.bStatus),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ElevatedButton(
                                  onPressed: () {
                                    _confirmBikePicked(booking);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Bike Picked'),
                                ),
                                SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: () {
                                    _confirmCancelRide(booking);
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red,
                                    side: BorderSide(color: Colors.red),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Cancel'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}