import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/controllers_post/updatestatus.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/image.dart';
import 'package:url_launcher/url_launcher.dart';

class CancellationRequests extends StatefulWidget {
  @override
  State<CancellationRequests> createState() => _CancellationRequestsState();
}

class _CancellationRequestsState extends State<CancellationRequests> {
  MyBookingController _bookingController = MyBookingController();
  TextEditingController _searchController = TextEditingController();
  List<BookingModel> _allBikes = [];
  List<BookingModel> _filteredBikes = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(_onSearchChanged);
  }

  Future<void> fetchdata() async {
    await _bookingController.fetchBikes();
    _allBikes = List.from(_bookingController.cancelreq);
    _filteredBikes = List.from(_allBikes);
    setState(() {});
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredBikes = List.from(_allBikes);
      } else {
        _filteredBikes = _allBikes.where((booking) {
          return (booking.bBikeName ?? "").toLowerCase().contains(query) ||
              (booking.bId?.toString() ?? "").contains(query) ||
              (booking.bBkId?.toString() ?? "").contains(query) ||
              (booking.bUId?.toString() ?? "").contains(query) ||
              (booking.uName ?? "").toLowerCase().contains(query) ||
              (booking.bPickupLocation ?? "").toLowerCase().contains(query) ||
              (booking.bDropLocation ?? "").toLowerCase().contains(query) ||
              (booking.bPickupDate ?? "").toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  // Format date from "2025-09-11" to "11 Sep 2025"
  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return '-';
    
    try {
      final date = DateTime.parse(dateString);
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      final day = date.day;
      final month = months[date.month - 1];
      final year = date.year;
      
      return '$day $month $year';
    } catch (e) {
      return dateString; // Return original if parsing fails
    }
  }

  // Format time from "09:11:00" to "09:11 AM"
  String _formatTime(String? timeString) {
    if (timeString == null || timeString.isEmpty) return '-';
    
    try {
      final parts = timeString.split(':');
      if (parts.length >= 2) {
        final hour = int.parse(parts[0]);
        final minute = parts[1];
        final period = hour >= 12 ? 'PM' : 'AM';
        final displayHour = hour % 12 == 0 ? 12 : hour % 12;
        
        return '$displayHour:$minute $period';
      }
      return timeString;
    } catch (e) {
      return timeString; // Return original if parsing fails
    }
  }

  bool _isPdf(String? url) {
    if (url == null) return false;
    return url.toLowerCase().endsWith('.pdf');
  }

  Future<void> _openPdf(String url, String documentType) async {
    try {
      final fullUrl = url.startsWith('http') ? url : "https://lunarsenterprises.com:6032/$url";
      if (await canLaunchUrl(Uri.parse(fullUrl))) {
        await launchUrl(
          Uri.parse(fullUrl),
          mode: LaunchMode.externalApplication,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening PDF: ${e.toString()}')),
      );
    }
  }

  Widget _buildDocumentWidget(String? documentUrl, String documentType) {
    final fullUrl = documentUrl?.startsWith('http') == true 
        ? documentUrl 
        : "https://lunarsenterprises.com:6032/${documentUrl ?? ''}";
    
    if (documentUrl == null || documentUrl.isEmpty) {
      return _buildPlaceholderIcon(Icons.document_scanner, 'No $documentType');
    }

    if (_isPdf(documentUrl)) {
      return GestureDetector(
        onTap: () {
          _openPdf(documentUrl, documentType);
        },
        child: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.picture_as_pdf, color: Colors.red, size: 24),
              SizedBox(height: 4),
              Text(
                'PDF',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      // It's an image
      return GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ImageView(image: documentUrl),
            ),
          );
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              fullUrl ?? '',
              width: 50,
              height: 50,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildPlaceholderIcon(Icons.broken_image, 'Error');
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
      );
    }
  }

  Widget _buildPlaceholderIcon(IconData icon, String tooltip) {
    return Tooltip(
      message: tooltip,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Icon(icon, color: Colors.grey, size: 24),
      ),
    );
  }

  void _showCustomerDetails(BuildContext context, BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Cancellation Request Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Customer Name', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike Name', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Booking ID', booking.bId?.toString() ?? 'N/A'),
            _buildDetailRow('User ID', booking.bUId?.toString() ?? 'N/A'),
            SizedBox(height: 16),
            Text(
              'Booking Details:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            _buildDetailRow('Pickup Location', booking.bPickupLocation ?? 'N/A'),
            _buildDetailRow('Drop Location', booking.bDropLocation ?? 'N/A'),
            _buildDetailRow('Pickup Date', _formatDate(booking.bPickupDate)),
            _buildDetailRow('Pickup Time', _formatTime(booking.bPicupTime)),
            _buildDetailRow('Drop Date', _formatDate(booking.bDropDate)),
            _buildDetailRow('Drop Time', _formatTime(booking.bDropTime)),
            _buildDetailRow('Total Amount', '₹${booking.bPrice?.toString() ?? 'N/A'}'),
            _buildDetailRow('Cancelling Reason', booking.viewReason ?? 'N/A'),

          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          if (booking.uMobile != null && booking.uMobile.toString().isNotEmpty)
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _makePhoneCall(booking.uMobile.toString()!);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
              child: Text('Call Customer', style: smalltextwhite,),
            ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[800]),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    try {
      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch phone app')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error making call: ${e.toString()}')),
      );
    }
  }

  void _confirmAcceptCancellation(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Accept Cancellation'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to accept this cancellation request?'),
            SizedBox(height: 16),
            _buildDetailRow('Customer', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Booking ID', booking.bId?.toString() ?? 'N/A'),
            _buildDetailRow('Amount', '₹${booking.bPrice?.toString() ?? 'N/A'}'),
            SizedBox(height: 8),
            Text(
              'This will cancel the booking and refund the amount.',
              style: TextStyle(
                color: Colors.orange[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _acceptCancellation(booking);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
            ),
            child: Text('Accept Cancellation'),
          ),
        ],
      ),
    );
  }

  void _confirmRejectCancellation(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Reject Cancellation'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to reject this cancellation request?'),
            SizedBox(height: 16),
            _buildDetailRow('Customer', booking.uName ?? 'N/A'),
            _buildDetailRow('Bike', booking.bBikeName ?? 'N/A'),
            _buildDetailRow('Booking ID', booking.bId?.toString() ?? 'N/A'),
            SizedBox(height: 8),
            Text(
              'The booking will continue as scheduled.',
              style: TextStyle(
                color: Colors.orange[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _rejectCancellation(booking);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Reject Cancellation'),
          ),
        ],
      ),
    );
  }

  void _acceptCancellation(BookingModel booking) {
    updatebookingstatus(
      context, 
      booking.bUId.toString(), 
      "cancelled", 
      booking.bId.toString(), 
      3
    );
    // .then((_) {
    //   ScaffoldMessenger.of(context).showSnackBar(
    //     SnackBar(content: Text('Cancellation request accepted')),
    //   );
      fetchdata();
    // });
  }

  void _rejectCancellation(BookingModel booking) {
    updatebookingstatus(
      context, 
      booking.bUId.toString(), 
      "Cancellation Rejected", 
      booking.bId.toString(), 
      3
    );
    // .then((_) {
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Cancellation request rejected')),
      // );
      fetchdata();
    // });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Cancellation Requests',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        children: [
          // Search Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Cancellation Requests',
                hintText: 'Search by bike name, ID, user, location...',
                prefixIcon: Icon(Icons.search, color: primaryColor),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBikes.length} cancellation request(s)',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 16,
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('Req ID')),
                      DataColumn(label: Text('Date')),
                      DataColumn(label: Text('Bike Name')),
                      DataColumn(label: Text('Bike ID')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('User ID')),
                      DataColumn(label: Text('Days')),
                      DataColumn(label: Text('Amount')),
                      DataColumn(label: Text('Pickup Location')),
                      DataColumn(label: Text('Pickup Date & Time')),
                      DataColumn(label: Text('Drop Location')),
                      DataColumn(label: Text('Drop Date & Time')),
                      DataColumn(label: Text('Rent')),
                      DataColumn(label: Text('User Image')),
                      DataColumn(label: Text('License')),
                      DataColumn(label: Text('Aadhaar')),
                      DataColumn(label: Text('Invoice')),
                      DataColumn(label: Text('Actions')),
                    ],
                    rows: _filteredBikes.map((booking) {
                      // Calculate number of days
                      int noOfDays = 1;
                      try {
                        if (booking.bPickupDate != null &&
                            booking.bPicupTime != null &&
                            booking.bDropDate != null &&
                            booking.bDropTime != null) {
                          DateTime pickupDate = DateTime.parse(booking.bPickupDate!);
                          DateTime dropDate = DateTime.parse(booking.bDropDate!);
                          
                          List<String> pickupTimeParts = booking.bPicupTime!.split(":");
                          List<String> dropTimeParts = booking.bDropTime!.split(":");
                          
                          DateTime pickupDateTime = DateTime(
                            pickupDate.year,
                            pickupDate.month,
                            pickupDate.day,
                            int.parse(pickupTimeParts[0]),
                            int.parse(pickupTimeParts[1]),
                          );
                          
                          DateTime dropDateTime = DateTime(
                            dropDate.year,
                            dropDate.month,
                            dropDate.day,
                            int.parse(dropTimeParts[0]),
                            int.parse(dropTimeParts[1]),
                          );
                          
                          noOfDays = dropDateTime.difference(pickupDateTime).inDays;
                          if (noOfDays <= 0) noOfDays = 1;
                        }
                      } catch (e) {
                        noOfDays = 1;
                      }
                      
                      return DataRow(
                        cells: [
                          DataCell(Text(
                            booking.bId?.toString() ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(_formatDate(booking.bookingDate))),
                          DataCell(Text(
                            booking.bBikeName ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(Text(booking.bBkId?.toString() ?? '-')),
                          DataCell(Text(
                            booking.uName ?? '-',
                            style: TextStyle(fontWeight: FontWeight.w500),
                          )),
                          DataCell(Text(booking.bUId?.toString() ?? '-')),
                          DataCell(Center(
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.orange.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.orange),
                              ),
                              child: Text(
                                noOfDays.toString(),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                            ),
                          )),
                          DataCell(Text(
                            '₹${booking.bPrice?.toString() ?? '-'}',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.green[700],
                            ),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bPickupLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bPickupDate),
                                  style: TextStyle(fontSize: 11),
                                ),
                                Text(
                                  _formatTime(booking.bPicupTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          )),
                          DataCell(Container(
                            width: 120,
                            child: Text(
                              booking.bDropLocation ?? '-',
                              overflow: TextOverflow.ellipsis,
                            ),
                          )),
                          DataCell(Container(
                            width: 140,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _formatDate(booking.bDropDate),
                                  style: TextStyle(fontSize: 11),
                                ),
                                Text(
                                  _formatTime(booking.bDropTime),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          )),
                          DataCell(Text(
                            '₹${booking.bPrice?.toString() ?? '-'}',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          )),
                          DataCell(_buildDocumentWidget(booking.bSelfie, 'User Image')),
                          DataCell(_buildDocumentWidget(booking.bLicense, 'License')),
                          DataCell(_buildDocumentWidget(booking.bAdharcard, 'Aadhaar')),
                          DataCell(_buildDocumentWidget(booking.invoice, 'Invoice')),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ElevatedButton(
                                  onPressed: () {
                                    _showCustomerDetails(context, booking);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Details'),
                                ),
                                SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: () {
                                    _confirmAcceptCancellation(booking);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    foregroundColor: Colors.white,
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Accept'),
                                ),
                                SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: () {
                                    _confirmRejectCancellation(booking);
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red,
                                    side: BorderSide(color: Colors.red),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    textStyle: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  child: Text('Reject'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}