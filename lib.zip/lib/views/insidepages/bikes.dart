import 'package:flutter/material.dart';
import 'package:getbike_admin/controllers/controllers.dart';
import 'package:getbike_admin/controllers_post/deletebike.dart';
import 'package:getbike_admin/models/models.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:getbike_admin/views/image.dart';
import 'package:getbike_admin/views/postpages/add_bike_page.dart';
import 'package:getbike_admin/utils/utilities.dart';

class VehiclesList extends StatefulWidget {
  @override
  State<VehiclesList> createState() => _VehiclesListState();
}

class _VehiclesListState extends State<VehiclesList> {
  BikeController _bikeController = BikeController();
  TextEditingController _searchController = TextEditingController();

  List<BikeModel> _allBikes = [];
  List<BikeModel> _filteredBikes = [];

  @override
  void initState() {
    super.initState();
    fetchdata();
    _searchController.addListener(_onSearchChanged);
  }

  Future<void> fetchdata() async {
    await _bikeController.fetchBikes();
    _allBikes = List.from(_bikeController.bikeList);
    _filteredBikes = List.from(_allBikes);
    setState(() {});
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredBikes = List.from(_allBikes);
      } else {
        _filteredBikes = _allBikes.where((bike) {
          return (bike.bName ?? "").toLowerCase().contains(query) ||
              (bike.bId?.toString() ?? "").contains(query) ||
              (bike.bGeartype ?? "").toLowerCase().contains(query) ||
              (bike.bStatus ?? "").toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  Widget _buildImageWidget(BikeModel bike) {
    if (bike.bikeimages.isNotEmpty && bike.bikeimages[0].imagePath != null) {
      final imageUrl = "https://lunarsenterprises.com:6032${bike.bikeimages[0].imagePath}";
      return GestureDetector(
        onTap: () {
          Navigations.push(ImageView(image: bike.bikeimages[0].imagePath!), context);
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              imageUrl,
              width: 60,
              height: 60,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildPlaceholderIcon();
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
      );
    } else {
      return _buildPlaceholderIcon();
    }
  }

  Widget _buildPlaceholderIcon() {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Icon(Icons.two_wheeler, color: Colors.grey, size: 24),
    );
  }

  Widget _buildRatingStars(double rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          rating.toStringAsFixed(1),
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.amber[700],
          ),
        ),
        SizedBox(width: 4),
        Icon(Icons.star, color: Colors.amber, size: 16),
      ],
    );
  }

  Widget _buildStatusBox(String text, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      constraints: BoxConstraints(
        minWidth: 60,
        maxWidth: 120,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 10,
        ),
        textAlign: TextAlign.center,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'available':
        return Colors.green;
      case 'unavailable':
      case 'maintenance':
        return Colors.red;
      case 'booked':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  Color _getMaintenanceColor(String status) {
    switch (status.toLowerCase()) {
      case 'good':
      case 'excellent':
        return Colors.green;
      case 'fair':
        return Colors.orange;
      case 'poor':
      case 'needs maintenance':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  void _showBikeDetails(BuildContext context, BikeModel bike) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Bike Details'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDetailRow('Bike ID', bike.bId?.toString() ?? 'N/A'),
              _buildDetailRow('Bike Name', bike.bName ?? 'N/A'),
              _buildDetailRow('Type', bike.bGeartype ?? 'N/A'),
              _buildDetailRow('Rent/Day', '₹${bike.bPrice?.toString() ?? 'N/A'}'),
              _buildDetailRow('Mileage', '${bike.bMilage?.toString() ?? 'N/A'} kmpl'),
              _buildDetailRow('Max Speed', '${bike.maxSpeed?.toString() ?? 'N/A'} km/h'),
              _buildDetailRow('BHP', bike.bBhp?.toString() ?? 'N/A'),
              _buildDetailRow('Fuel Type', bike.bFueltype ?? 'N/A'),
              _buildDetailRow('Location', bike.bLocation ?? 'N/A'),
              _buildDetailRow('Extras', bike.bExtras ?? 'N/A'),
              _buildDetailRow('Rating', '${bike.bRatings?.toString() ?? 'N/A'} ⭐'),
              _buildDetailRow('Maintenance', bike.maintainceStatus ?? 'N/A'),
              _buildDetailRow('Status', bike.bStatus ?? 'N/A'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[800]),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteBike(BuildContext context, BikeModel bike) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Bike'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to delete this bike?'),
            SizedBox(height: 16),
            _buildDetailRow('Bike Name', bike.bName ?? 'N/A'),
            _buildDetailRow('Bike ID', bike.bId?.toString() ?? 'N/A'),
            _buildDetailRow('Type', bike.bGeartype ?? 'N/A'),
            SizedBox(height: 8),
            Text(
              'This action cannot be undone.',
              style: TextStyle(
                color: Colors.red[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteBike(bike);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Delete Bike'),
          ),
        ],
      ),
    );
  }

  void _deleteBike(BikeModel bike) {
    Deletebike().deleteBike(context, bike.bId.toString());
    // .then((_) {
    //   ScaffoldMessenger.of(context).showSnackBar(
    //     SnackBar(
    //       content: Text('Bike ${bike.bName} deleted successfully'),
    //       backgroundColor: Colors.red,
    //     ),
    //   );
      fetchdata();
    // });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Vehicle Management',
          style: TextStyle(
            color: primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: primaryColor),
      ),
      body: Column(
        children: [
          // Search and Add Bike Section
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      labelText: 'Search Vehicles',
                      hintText: 'Search by name, ID, type, status...',
                      prefixIcon: Icon(Icons.search, color: primaryColor),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey[400]!),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: primaryColor, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                ),
                SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => AddBikeDialog()),
                    ).then((_) => fetchdata());
                  },
                  icon: Icon(Icons.two_wheeler, size: 20),
                  label: Text('Add New Bike'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 8),
          
          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBikes.length} vehicle(s) found',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                if (_searchController.text.isNotEmpty)
                  TextButton(
                    onPressed: () {
                      _searchController.clear();
                    },
                    child: Text(
                      'Clear Search',
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
              ],
            ),
          ),
          
          // Data Table
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    columnSpacing: 20,
                    horizontalMargin: 16,
                    headingRowHeight: 50,
                    dataRowMinHeight: 70,
                    dataRowMaxHeight: 70, // Fixed height to prevent constraints issues
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    dataTextStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[800],
                    ),
                    columns: const [
                      DataColumn(label: Text('ID'), numeric: true),
                      DataColumn(label: Text('Name')),
                      DataColumn(label: Text('Image')),
                      DataColumn(label: Text('Type')),
                      DataColumn(label: Text('Rent/Day'), numeric: true),
                      DataColumn(label: Text('Mileage'), numeric: true),
                      DataColumn(label: Text('Power'), numeric: true),
                      DataColumn(label: Text('BHP'), numeric: true),
                      DataColumn(label: Text('Extras')),
                      DataColumn(label: Text('Rating'), numeric: true),
                      DataColumn(label: Text('Maintenance')),
                      DataColumn(label: Text('Status')),
                      DataColumn(label: Text('Actions')),
                    ],
                    rows: _filteredBikes.map((bike) {
                      return DataRow(
                        cells: [
                          DataCell(
                            SizedBox(
                              width: 40,
                              child: Text(
                                bike.bId?.toString() ?? '-',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 120,
                              child: Text(
                                bike.bName ?? '-',
                                style: TextStyle(fontWeight: FontWeight.w500),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 60,
                              height: 60,
                              child: _buildImageWidget(bike),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 80,
                              child: Text(
                                bike.bGeartype ?? '-',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 70,
                              child: Text(
                                '₹${bike.bPrice?.toString() ?? '-'}',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.green[700],
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 60,
                              child: Text('${bike.bMilage?.toString() ?? '-'}'),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 60,
                              child: Text('${bike.maxSpeed?.toString() ?? '-'}'),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 40,
                              child: Text(bike.bBhp?.toString() ?? '-'),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 100,
                              child: Text(
                                bike.bExtras ?? '-',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 60,
                              child: _buildRatingStars(bike.bRatings?.toDouble() ?? 0),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 90,
                              child: _buildStatusBox(
                                bike.maintainceStatus ?? 'Unknown',
                                _getMaintenanceColor(bike.maintainceStatus ?? ''),
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 90,
                              child: _buildStatusBox(
                                bike.bStatus ?? 'Unknown',
                                _getStatusColor(bike.bStatus ?? ''),
                              ),
                            ),
                          ),
                          DataCell(
                            SizedBox(
                              width: 120,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.visibility, size: 18),
                                    color: Colors.blue,
                                    onPressed: () {
                                      _showBikeDetails(context, bike);
                                    },
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.edit, size: 18),
                                    color: Colors.orange,
                                    onPressed: () => _showEditDialog(context, bike),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete, size: 18),
                                    color: Colors.red,
                                    onPressed: () {
                                      _confirmDeleteBike(context, bike);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchdata,
        backgroundColor: primaryColor,
        child: Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }

  void _showEditDialog(BuildContext context, BikeModel bike) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Bike - Coming Soon'),
        content: Text('Edit functionality will be implemented in the next update.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}