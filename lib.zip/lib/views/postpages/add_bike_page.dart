import 'dart:io';
import 'package:flutter/material.dart';
import 'package:getbike_admin/views/insidepages/map_picker_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:getbike_admin/controllers_post/add_bike.dart';
import 'package:getbike_admin/utils/utilities.dart';

class AddBikeDialog extends StatefulWidget {
  const AddBikeDialog({super.key});

  @override
  State<AddBikeDialog> createState() => _AddBikeDialogState();
}

class _AddBikeDialogState extends State<AddBikeDialog> {
  final TextEditingController bikeNameController = TextEditingController();
  final TextEditingController typeController = TextEditingController();
  final TextEditingController rentController = TextEditingController();
  final TextEditingController mileageController = TextEditingController();
  final TextEditingController powerController = TextEditingController();
  final TextEditingController bhpController = TextEditingController();
  final TextEditingController maxSpeedController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController gearTypeController = TextEditingController();
  final TextEditingController fuelTypeController = TextEditingController();
  final TextEditingController maintenanceStatusController = TextEditingController();
  final TextEditingController extrasController = TextEditingController();

  // Location coordinates
  double? latitude;
  double? longitude;

  // Centers list and controller
  final TextEditingController centerInputController = TextEditingController();
  List<Map<String, dynamic>> centersList = [];

  // Image picker
  List<File> selectedImages = [];

  Future<void> pickImages() async {
    final ImagePicker picker = ImagePicker();
    final List<XFile>? images = await picker.pickMultiImage();
    if (images != null) {
      setState(() {
        selectedImages = images.map((xfile) => File(xfile.path)).toList();
      });
    }
  }

  @override
  void dispose() {
    bikeNameController.dispose();
    typeController.dispose();
    rentController.dispose();
    mileageController.dispose();
    powerController.dispose();
    bhpController.dispose();
    maxSpeedController.dispose();
    descriptionController.dispose();
    locationController.dispose();
    gearTypeController.dispose();
    fuelTypeController.dispose();
    maintenanceStatusController.dispose();
    extrasController.dispose();
    centerInputController.dispose();
    super.dispose();
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {int maxLines = 1, bool readOnly = false, VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: TextFormField(
        controller: controller,
        readOnly: readOnly,
        onTap: onTap,
        maxLines: maxLines,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: primaryColor),
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  void _submitBikeData() {
    // Validate required fields
    if (bikeNameController.text.isEmpty ||
        typeController.text.isEmpty ||
        rentController.text.isEmpty ||
        descriptionController.text.isEmpty ||
        locationController.text.isEmpty ||
        selectedImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all required fields and select at least one image'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Call the AddBike controller
    AddBike().addBikes(
      context,
      bikeNameController.text,
      "", // ratings
      "", // review
      descriptionController.text,
      rentController.text,
      locationController.text,
      extrasController.text,
      mileageController.text,
      gearTypeController.text,
      fuelTypeController.text,
      bhpController.text,
      powerController.text,
      maxSpeedController.text,
      maintenanceStatusController.text,
      selectedImages,
      centersList,
      latitude.toString(),
      longitude.toString(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add New Bike"),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // ✅ General Info
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    _buildTextField(bikeNameController, "Bike Name", Icons.pedal_bike),
                    _buildTextField(typeController, "Type", Icons.category),
                    _buildTextField(rentController, "Rent/Day", Icons.currency_rupee),
                    _buildTextField(descriptionController, "Description", Icons.description, maxLines: 3),
                    _buildTextField(extrasController, "Extras", Icons.extension, maxLines: 2),
                    _buildTextField(
                      locationController,
                      "Location",
                      Icons.location_on,
                      readOnly: true,
                      onTap: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  MapPickerScreen())
                        );
                        if (result != null) {
                          setState(() {
                            locationController.text = result['address'];
                            latitude = result['latitude'];
                            longitude = result['longitude'];
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // ✅ Specifications
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    _buildTextField(mileageController, "Mileage", Icons.speed),
                    _buildTextField(gearTypeController, "Gear Type", Icons.settings),
                    _buildTextField(fuelTypeController, "Fuel Type", Icons.local_gas_station),
                    _buildTextField(powerController, "Power", Icons.bolt),
                    _buildTextField(bhpController, "BHP", Icons.flash_on),
                    _buildTextField(maxSpeedController, "Max Speed", Icons.speed),
                    _buildTextField(maintenanceStatusController, "Maintenance Status", Icons.build_circle),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // ✅ Centers Section
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Service Centers",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: centerInputController,
                            readOnly: true,
                            decoration: const InputDecoration(
                              labelText: "Add Center (Pick from Map)",
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.add_location_alt, color: Colors.blue),
                          onPressed: () async {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const MapPickerScreen()),
                            );
                            if (result != null) {
                              setState(() {
                                centersList.add({
                                  'address': result['address'],
                                  'latitude': result['latitude'],
                                  'longitude': result['longitude'],
                                });
                                centerInputController.text = result['address'];
                              });
                            }
                          },
                        )
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (centersList.isNotEmpty)
                      Wrap(
                        spacing: 8,
                        children: centersList
                            .asMap()
                            .entries
                            .map(
                              (entry) => Chip(
                                label: Text(entry.value['address']),
                                onDeleted: () => setState(() => centersList.removeAt(entry.key)),
                              ),
                            )
                            .toList(),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // ✅ Image Picker
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Bike Images",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton.icon(
                      onPressed: pickImages,
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      icon: const Icon(Icons.image),
                      label: Text("Pick Images (${selectedImages.length})"),
                    ),
                    const SizedBox(height: 8),
                    if (selectedImages.isNotEmpty)
                      SizedBox(
                        height: 110,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: selectedImages.length,
                          itemBuilder: (context, index) => Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(4.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.file(
                                    selectedImages[index],
                                    width: 100,
                                    height: 100,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectedImages.removeAt(index);
                                    });
                                  },
                                  child: const CircleAvatar(
                                    radius: 12,
                                    backgroundColor: Colors.red,
                                    child: Icon(Icons.close, size: 16, color: Colors.white),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // ✅ Submit Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _submitBikeData,
                child: Text("Submit", style: normalwhite),
              ),
            ),
          ],
        ),
      ),
    );
  }
}