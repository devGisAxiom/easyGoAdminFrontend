import 'package:flutter/material.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:getbike_admin/utils/utilities.dart';
import 'package:getbike_admin/views/home.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final _formKey = GlobalKey<FormState>();
  bool _rememberMe = false;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // void _submit() {
  //   if (_formKey.currentState!.validate()) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(content: Text('Signing in...')),
  //     );
  //   }
  // }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 32),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x1A000000),
                      blurRadius: 15,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                constraints: const BoxConstraints(maxWidth: 400),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Welcome Back',
                        style: intercaps ,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Sign in to your admin account',
                        style: mediumblack ,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),

                      // Email
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Email Address',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: Color(0xFF334155),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                          hintText: 'admin@example.com',
                          prefixIcon: Icon(
                            Icons.email_outlined,
                            color: Color(0xFF94A3B8),
                          ),
                        ),
                   style:  TextStyle(color: Colors.black) ,

                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please fill out this field.';
                          }
                          if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                            return 'Please enter a valid email address.';
                          }
                          return null;
                        },
                      ),

                      const SizedBox(height: 24),

                      // Password
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Password',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: Color(0xFF334155),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _passwordController,
                        obscureText: true,
                        decoration: const InputDecoration(
                          hintText: '••••••••',
                          prefixIcon: Icon(
                            Icons.lock_outline,
                            color: Color(0xFF94A3B8),
                          ),
                        ),
                        style:  TextStyle(color: Colors.black) ,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please fill out this field.';
                          }
                          return null;
                        },
                      ),

                      const SizedBox(height: 20),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Checkbox(
                                value: _rememberMe,
                                onChanged: (value) {
                                  setState(() {
                                    _rememberMe = value ?? false;
                                  });
                                },
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Remember me',
                               style: smalltextgrey,
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: () {
                              // Forgot password logic
                            },
                            child: Text(
                              'Forgot password?',
                              style: colortextmall
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      // Sign In Button
                      SizedBox(
                        height: 40,
                        width: double.infinity,
                        child: ElevatedButton(
                           style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor
                           ),
                          onPressed: (){
                                   
                                   Navigations.push(HomeScreen(), context);
                          },
                          child: Text('Sign in' , style: normalwhite,),
              
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Support Info
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: normalgrey ,
                  children:  [
                    TextSpan(text: 'Need help? Contact '),
                    TextSpan(
                      text: 'support@example.com',
                      style: colortext
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
