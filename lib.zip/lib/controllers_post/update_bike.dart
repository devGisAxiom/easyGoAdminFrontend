import 'dart:convert';
import 'package:getbike_admin/views/home.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:getbike_admin/APIs/apis.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> updateBooking(
  BuildContext context,
  String bikeId,
  String bikename,
  String ratings,
  String review,
  String description,
  String rate,
  String location,
  String extras,
  String milage,
  String geartype,
  String fueltype,
  String bhp,
) async {
  print("1");

  final SharedPreferences prefs = await SharedPreferences.getInstance();
  String? userId = prefs.getString("user_id");

  if (userId == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("User not logged in")),
    );
    return;
  }

  var data = {
    "b_id": bikeId,
    "name": bikename,
    "ratings": ratings,
    "review": review,
    "description": description,
    "rate": rate,
    "location": location,
    "extras": extras,
    "milage": milage,
    "geartype": geartype,
    "fueltype": fueltype,
    "bhp": bhp,
  };

  var url = EditBikesAPI;
  print("2");

  try {
    print("3");

    var response = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(data),
    );
    print("4");

    print(response.statusCode);
    print(response.body);

    if (response.statusCode == 200) {
      print("5");

      var jsonData = jsonDecode(response.body);

      print(jsonData);
      print("6");

      if (jsonData['result'] == true) {
        print("7");

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(jsonData['message'] ?? "Booking updated successfully")),
        );

        Navigations.pushAndRemoveUntil(HomeScreen(navindex: 6), context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(jsonData['message'] ?? "Update failed")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Server error: ${response.statusCode}")),
      );
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Network Error")),
    );
  }
}
