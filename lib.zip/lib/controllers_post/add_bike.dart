import 'dart:io';
import 'package:flutter/material.dart';
import 'package:getbike_admin/APIs/apis.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http_parser/http_parser.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class AddBike {
  void addBikes(
    BuildContext context,
    String name,
    String ratings,
    String review,
    String description,
    String rate,
    String location,
    String extras,
    String milage,
    String geartype,
    String fueltype,
    String bhp,
    String distance,
    String max_speed,
    String maintaince_status,
    List<File> imageFiles, // Multiple images
     List<Map<String, dynamic>> centersList, //tersList,
    String latitude,
    String longitude,



  ) async {
    var url = AddBikeAPI;
  print(url);
    var request = http.MultipartRequest('POST', Uri.parse(url));

    // Add form fields
request.fields['name'] = name;
// request.fields['ratings'] = ratings;
// request.fields['review'] = review;
request.fields['description'] = description;
request.fields['rate'] = rate;
request.fields['location'] = location;
request.fields['extras'] = extras;
request.fields['milage'] = milage;
request.fields['geartype'] = geartype;
request.fields['fueltype'] = fueltype;
request.fields['bhp'] = bhp;
request.fields['distance'] = distance;
request.fields['max_speed'] = max_speed;
request.fields['maintaince_status'] = maintaince_status;
request.fields['latitude'] = latitude;
request.fields['longitude'] = longitude;

// ✅ Fix for centers list
request.fields['centerList'] = jsonEncode(centersList);


//      name, description, rate, location, extras, milage, geartype, fueltype, bhp, distance, 
// max_speed, maintaince_status, , latitude, longitude 
// image:

for (var imageFile in imageFiles) {
  final mimeType = lookupMimeType(imageFile.path) ?? 'image/jpeg';
  final typeSplit = mimeType.split('/');

  request.files.add(
    await http.MultipartFile.fromPath(
      'image',
      imageFile.path,
      contentType: MediaType(typeSplit[0], typeSplit[1]),
    ),
  );
}


    try {
      print("try starts here");
      var response = await request.send();
      var responseData = await response.stream.bytesToString();

      print("POST URL: $url");
      print("Status Code: ${response.statusCode}");
      print("Response: $responseData");

      if (response.statusCode == 200) {
        var jsonData = jsonDecode(responseData);

        if (jsonData['result'] == true) {
          // Fluttertoast.showToast(
          //   msg: jsonData['message'] ?? "Bike added successfully",
          //   gravity: ToastGravity.BOTTOM,
          // );

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(jsonData['message'] ?? "Bike added successfully",)));
          Navigator.pop(context);
        } else {
          // Fluttertoast.showToast(
          //   msg: jsonData['message'] ?? "Something went wrong",
          //   gravity: ToastGravity.BOTTOM,
          // );

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(jsonData['message'] ?? "something went wrong",)));

        }
      } else {
        // Fluttertoast.showToast(
        //   msg: "Server Error: ${response.statusCode}",
        //   gravity: ToastGravity.BOTTOM,
        // );
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Server Error: ${response.statusCode}")));

      }
    } catch (e) {
      // Fluttertoast.showToast(
      //   msg: "Error: $e",
      //   gravity: ToastGravity.BOTTOM,
      // );
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e",)));

    }
  }
}
