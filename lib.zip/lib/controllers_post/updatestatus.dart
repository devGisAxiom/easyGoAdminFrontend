
  import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:getbike_admin/APIs/apis.dart';
import 'package:getbike_admin/utils/navigations.dart';
import 'package:getbike_admin/views/home.dart';
import 'package:http/http.dart' as http;

void updatebookingstatus(
    BuildContext context,
    String user_id,
    String status,
    String booking_id,
    int navindex
  ) async {

    print("booking id $booking_id");

    var data = {
        "b_id":  booking_id,
        "b_status": status,
        "b_u_id": user_id
    };


    var url = BookingStatusAPI;

    var response = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(data),
    );

    var jsonData = jsonDecode(response.body);
    // var user = jsonData['user'];

    print(response.body);

    if (response.statusCode == 200) {
      var jsonData = jsonDecode(response.body);

      if (jsonData['result'] == true) {
    
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(jsonData["message"])));

       Navigations.pushAndRemoveUntil(HomeScreen(navindex: navindex,), context);
      }
    } else if (jsonData['result'] == false) {
         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(jsonData["message"])));

    } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Network Error")));

    }
  }
